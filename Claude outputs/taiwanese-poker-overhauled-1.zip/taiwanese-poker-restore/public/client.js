(() => {
  let es = null; // EventSource

  async function api(pathname, body) {
    const res = await fetch(pathname, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    });
    return res.json();
  }

  function connectStream() {
    if (es) { es.close(); }
    es = new EventSource(`/api/stream?code=${encodeURIComponent(state.code)}&playerId=${encodeURIComponent(state.playerId)}&token=${encodeURIComponent(state.token)}`);
    es.addEventListener('room_state', (e) => handleRoomState(JSON.parse(e.data)));
    es.addEventListener('your_hand', (e) => handleYourHand(JSON.parse(e.data)));
    es.addEventListener('results', (e) => handleResults(JSON.parse(e.data)));
    return es;
  }

  const SUIT_SYMBOL = { s: '♠', h: '♥', d: '♦', c: '♣' };
  const SUIT_CLASS = { s: 'suit-s', h: 'suit-h', d: 'suit-d', c: 'suit-c' }; // 4-color deck: s=black h=red d=blue c=green
  const CAPACITY = { one: 1, two: 2, four: 4 }; // final-hand shape
  const SLOT_TITLES = { one: '1-Card Hand', two: '2-Card Hand', four: '4-Card PLO Hand' };
  const STORAGE_KEY = 'taiwanese-poker-session';

  // ---------- card sorting ----------
  // A shared display preference (not per-hand state) for how "your cards" areas lay
  // themselves out: 'dealt' (whatever order the server sent, i.e. unsorted), 'rank'
  // (high to low, ties broken by suit), or 'suit' (grouped s/h/d/c, high to low within
  // each suit). Applies to the live game's tray and Practice Mode's tray — anywhere
  // you're looking at a raw pile of your own cards deciding what to do with them.
  // Doesn't touch cards already placed into hand slots —
  // those stay in the order you put them, since reordering a hand you've already built
  // would just be confusing. Persisted across visits like the sound preference.
  const CARD_SORT_KEY = 'taiwanese-poker-card-sort';
  const RANK_ORDER = '23456789TJQKA';
  const SUIT_ORDER = ['s', 'h', 'd', 'c'];
  let cardSortMode = 'dealt';
  try {
    const savedSort = localStorage.getItem(CARD_SORT_KEY);
    if (savedSort === 'rank' || savedSort === 'suit' || savedSort === 'dealt') cardSortMode = savedSort;
  } catch (e) { /* localStorage unavailable — default stays 'dealt' */ }

  function sortCards(cards, mode) {
    if (mode !== 'rank' && mode !== 'suit') return cards; // 'dealt' — leave as-is
    const arr = cards.slice();
    const rankOf = (c) => RANK_ORDER.indexOf(c[0]);
    const suitOf = (c) => SUIT_ORDER.indexOf(c[1]);
    if (mode === 'rank') {
      arr.sort((a, b) => rankOf(b) - rankOf(a) || suitOf(a) - suitOf(b));
    } else {
      arr.sort((a, b) => suitOf(a) - suitOf(b) || rankOf(b) - rankOf(a));
    }
    return arr;
  }

  // Wires up a "Sort: Dealt / Rank / Suit" button group inside `containerId`. Clicking a
  // button updates the shared cardSortMode, persists it, keeps every such control on the
  // page in sync (even ones on screens not currently visible), and re-renders whichever
  // screen this particular control belongs to via `onChange`.
  function wireSortControl(containerId, onChange) {
    const container = el(containerId);
    if (!container) return;
    function syncActiveStates() {
      document.querySelectorAll('.sort-btn').forEach((b) => b.classList.toggle('active', b.dataset.sort === cardSortMode));
    }
    container.querySelectorAll('.sort-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        if (btn.dataset.sort === cardSortMode) return;
        cardSortMode = btn.dataset.sort;
        try { localStorage.setItem(CARD_SORT_KEY, cardSortMode); } catch (e) { /* ignore */ }
        syncActiveStates();
        onChange();
      });
    });
    syncActiveStates();
  }

  const el = (id) => document.getElementById(id);
  const show = (id) => el(id).classList.remove('hidden');
  const hide = (id) => el(id).classList.add('hidden');

  const state = {
    code: null,
    playerId: null,
    token: null,
    name: null,
    room: null,
    myHand: null,
    assignment: { one: [], two: [], four: [] },
    selectedCard: null,
    locked: false
  };
  let revealInProgress = false;

  // ---------- win sounds ----------
  // Synthesized with the Web Audio API (a couple of short oscillator tones per cue)
  // instead of shipping audio files — zero extra assets to host, and it means "add a
  // sound" doesn't turn into "find/license/host an mp3." The win/homerun fanfares fire in
  // live PvP games only (at the results reveal) — Practice Mode runs hands too quickly in
  // succession for those to feel good rather than annoying. Rapid Fire has its own much
  // shorter correct-answer blip (playCorrectSound), which is sized for hearing it many
  // times a minute.
  const SOUND_PREF_KEY = 'taiwanese-poker-sound-enabled';
  let soundEnabled = true;
  try {
    const saved = localStorage.getItem(SOUND_PREF_KEY);
    if (saved !== null) soundEnabled = saved === 'true';
  } catch (e) { /* localStorage unavailable (e.g. private mode) — default stays on */ }

  let audioCtx = null;
  function getAudioCtx() {
    try {
      if (!audioCtx) {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return null;
        audioCtx = new Ctx();
      }
      if (audioCtx.state === 'suspended') audioCtx.resume();
      return audioCtx;
    } catch (e) {
      return null;
    }
  }

  function playTone(ctx, freq, startTime, duration, peakGain, type) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type || 'sine';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(peakGain, startTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(startTime);
    osc.stop(startTime + duration + 0.05);
  }

  // A short ascending major arpeggio — the standard "you won this hand" chime.
  function playWinSound() {
    if (!soundEnabled) return;
    const ctx = getAudioCtx();
    if (!ctx) return;
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => { // C5 E5 G5 C6
      playTone(ctx, freq, now + i * 0.09, 0.35, 0.16);
    });
  }

  // A bigger fanfare for a homerun — the same arpeggio plus an extra high note and a
  // sparkly triangle-wave tail, so it's clearly a step up from a plain win.
  function playHomerunSound() {
    if (!soundEnabled) return;
    const ctx = getAudioCtx();
    if (!ctx) return;
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.5, 1318.51].forEach((freq, i) => { // C5 E5 G5 C6 E6
      playTone(ctx, freq, now + i * 0.08, 0.4, 0.19);
    });
    playTone(ctx, 1567.98, now + 0.42, 0.55, 0.13, 'triangle'); // G6 sparkle on top
  }

  function setSoundEnabled(on) {
    soundEnabled = on;
    try { localStorage.setItem(SOUND_PREF_KEY, String(on)); } catch (e) { /* ignore */ }
    const btn = el('btnSoundToggle');
    if (btn) {
      btn.textContent = on ? '🔊' : '🔇';
      btn.classList.toggle('muted', !on);
      btn.title = on ? 'Sound on — click to mute' : 'Sound off — click to unmute';
    }
  }

  const soundToggleBtn = el('btnSoundToggle');
  if (soundToggleBtn) {
    setSoundEnabled(soundEnabled);
    soundToggleBtn.addEventListener('click', () => setSoundEnabled(!soundEnabled));
  }

  // ---------- card rendering ----------
  function cardEl(card, { size = 'normal', usedInBest = false } = {}) {
    const rank = card[0];
    const suit = card[1];
    const div = document.createElement('div');
    div.className = 'playing-card' + (size === 'small' ? ' small' : '') + ' ' + SUIT_CLASS[suit] + (usedInBest ? ' used-in-best' : '');
    div.dataset.card = card;
    div.innerHTML = `<span class="rank">${rank}</span><span class="suit">${SUIT_SYMBOL[suit]}</span>`;
    return div;
  }

  function cardRow(cards, opts = {}) {
    const wrap = document.createElement('div');
    wrap.style.display = 'flex';
    wrap.style.gap = '4px';
    wrap.style.flexWrap = 'wrap';
    cards.forEach((c) => wrap.appendChild(cardEl(c, opts)));
    return wrap;
  }

  // ---------- persistence ----------
  function saveSession() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      code: state.code, playerId: state.playerId, token: state.token, name: state.name
    }));
  }
  function loadSession() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    } catch { return null; }
  }
  function clearSession() {
    localStorage.removeItem(STORAGE_KEY);
  }

  // ---------- landing ----------
  // Scoped to [data-tab] on purpose: other screens reuse the .tab-btn look for their own
  // in-screen tabs (Rapid Fire's Quiz/Mistakes), and those carry a different data attribute
  // and manage their own active state.
  document.querySelectorAll('.tab-btn[data-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn[data-tab]').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.tab-content').forEach((c) => c.classList.add('hidden'));
      el('tab-' + btn.dataset.tab).classList.remove('hidden');
    });
  });

  function landingError(msg) {
    el('landingError').textContent = msg;
    show('landingError');
  }

  el('btnCreate').addEventListener('click', async () => {
    const name = el('createName').value.trim() || 'Host';
    const maxPlayers = Number(el('createMax').value);
    const bots = Number(el('createBots').value) || 0;
    const res = await api('/api/create_room', { name, maxPlayers, bots });
    if (!res.ok) return landingError(res.error);
    state.code = res.code; state.playerId = res.playerId; state.token = res.token; state.name = name;
    saveSession();
    connectStream();
    enterLobby();
  });

  el('btnJoin').addEventListener('click', async () => {
    const name = el('joinName').value.trim() || 'Player';
    const code = el('joinCode').value.trim().toUpperCase();
    if (!code) return landingError('Enter a room code.');
    const res = await api('/api/join_room', { code, name });
    if (!res.ok) return landingError(res.error);
    state.code = res.code; state.playerId = res.playerId; state.token = res.token; state.name = name;
    saveSession();
    connectStream();
    enterLobby();
  });

  // ---------- lobby ----------
  function enterLobby() {
    el('roomCodeLabel').textContent = state.code;
    show('roomBadge');
    el('lobbyCode').textContent = state.code;
    el('shareLink').value = `${location.origin}/?join=${state.code}`;
    ['landing', 'lobby'].forEach((s) => (s === 'lobby' ? show : hide)('screen-' + s));
    hide('screen-game'); hide('screen-results');
  }

  el('btnCopyLink').addEventListener('click', () => {
    el('shareLink').select();
    navigator.clipboard?.writeText(el('shareLink').value).catch(() => {});
  });

  el('btnAddBot').addEventListener('click', () => botAction('/api/add_bot', {}));

  el('btnStart').addEventListener('click', async () => {
    const res = await api('/api/start_game', { code: state.code, playerId: state.playerId, token: state.token });
    if (res && !res.ok) alert(res.error);
  });

  function lobbyBotError(msg) {
    const node = el('lobbyBotError');
    node.textContent = msg;
    node.classList.toggle('hidden', !msg);
  }

  async function botAction(pathname, extra) {
    const res = await api(pathname, Object.assign({ code: state.code, playerId: state.playerId, token: state.token }, extra));
    lobbyBotError(res && res.ok ? '' : (res && res.error) || 'Something went wrong.');
    return res;
  }

  function renderLobby(room) {
    el('lobbyCount').textContent = room.players.length;
    el('lobbyMax').textContent = room.maxPlayers;
    const isHost = room.hostId === state.playerId;

    // A room_state broadcast can land while the host is mid-rename, so remember which bot
    // name field was focused (and the caret) and restore it after the rebuild — otherwise
    // every keystroke would be yanked back to the server's copy of the name.
    const active = document.activeElement;
    const editingId = active && active.classList && active.classList.contains('bot-name-input')
      ? active.dataset.botId : null;
    const editingValue = editingId ? active.value : null;
    const caret = editingId ? active.selectionStart : null;

    const list = el('lobbyPlayers');
    list.innerHTML = '';
    room.players.forEach((p) => {
      const li = document.createElement('li');
      li.className = p.isBot ? 'is-bot' : '';

      if (p.isBot && isHost) {
        const input = document.createElement('input');
        input.className = 'bot-name-input';
        input.dataset.botId = p.id;
        input.value = p.name;
        input.maxLength = 20;
        input.setAttribute('aria-label', 'Bot name');
        const commit = () => {
          const name = input.value.trim();
          if (!name || name === p.name) { input.value = p.name; return; }
          botAction('/api/rename_bot', { botId: p.id, name });
        };
        input.addEventListener('blur', commit);
        input.addEventListener('keydown', (ev) => {
          if (ev.key === 'Enter') { ev.preventDefault(); input.blur(); }
          if (ev.key === 'Escape') { input.value = p.name; input.blur(); }
        });
        li.appendChild(input);
      } else {
        const label = document.createElement('span');
        label.textContent = p.name + (p.id === state.playerId ? ' (you)' : '')
          + (!p.isBot && !p.connected ? ' — offline' : '');
        if (!p.isBot && !p.connected) label.classList.add('offline');
        li.appendChild(label);
      }

      const tags = document.createElement('span');
      tags.className = 'lobby-tags';
      if (p.isBot) {
        const bt = document.createElement('span');
        bt.className = 'tag bot-tag';
        bt.textContent = '🤖 GTO BOT';
        tags.appendChild(bt);
      }
      if (p.id === room.hostId) {
        const tag = document.createElement('span');
        tag.className = 'tag';
        tag.textContent = 'HOST';
        tags.appendChild(tag);
      }
      if (p.isBot && isHost && room.phase === 'lobby') {
        const rm = document.createElement('button');
        rm.className = 'bot-remove';
        rm.title = 'Remove this bot';
        rm.textContent = '✕';
        rm.addEventListener('click', () => botAction('/api/remove_bot', { botId: p.id }));
        tags.appendChild(rm);
      }
      li.appendChild(tags);
      list.appendChild(li);
    });

    if (editingId) {
      const again = list.querySelector(`.bot-name-input[data-bot-id="${editingId}"]`);
      if (again) {
        again.value = editingValue;
        again.focus();
        try { again.setSelectionRange(caret, caret); } catch (e) { /* not supported, fine */ }
      }
    }

    const canAddBot = isHost && room.phase === 'lobby' && room.players.length < room.maxPlayers;
    el('lobbyBotRow').classList.toggle('hidden', !isHost || room.phase !== 'lobby');
    el('btnAddBot').disabled = !canAddBot;
    el('btnAddBot').textContent = canAddBot ? '+ Add GTO bot' : 'Table full';

    if (isHost && room.players.length >= 2) {
      show('btnStart');
      el('lobbyHint').textContent = '';
    } else {
      hide('btnStart');
      el('lobbyHint').textContent = isHost ? 'Need at least 2 players to start.' : 'Waiting for the host to start the game…';
    }
  }

  // ---------- arranging ----------
  function liveCapacity() {
    return CAPACITY;
  }

  function handleYourHand({ hand, assignment }) {
    state.myHand = hand;
    state.locked = !!assignment;
    state.assignment = assignment ? deepCopy(assignment) : { one: [], two: [], four: [] };
    state.selectedCard = null;
    hide('screen-lobby'); hide('screen-results');
    show('screen-game');
    renderGame();
  }

  function deepCopy(o) { return JSON.parse(JSON.stringify(o)); }

  function trayCards() {
    const used = new Set([...state.assignment.one, ...state.assignment.two, ...state.assignment.four]);
    return sortCards(state.myHand.filter((c) => !used.has(c)), cardSortMode);
  }

  function renderGame() {
    el('handNumber').textContent = state.room ? state.room.handNumber : '';

    el('slotTitleOne').textContent = '1-Card Hand';
    el('slotTitleTwo').textContent = '2-Card Hand';
    el('slotTitleFour').textContent = '4-Card PLO Hand';

    const cap = CAPACITY;
    const disabled = state.locked;
    ['one', 'two', 'four'].forEach((slot) => {
      const container = el('slot' + capitalize(slot));
      container.innerHTML = '';
      state.assignment[slot].forEach((c) => {
        const cardNode = cardEl(c);
        if (!disabled) {
          cardNode.addEventListener('click', () => {
            state.assignment[slot] = state.assignment[slot].filter((x) => x !== c);
            state.selectedCard = null;
            renderGame();
          });
        }
        container.appendChild(cardNode);
      });
    });

    const tray = el('tray');
    tray.innerHTML = '';
    if (disabled) {
      const msg = document.createElement('div');
      msg.className = 'hint';
      msg.textContent = 'Hand locked — waiting for other players…';
      tray.appendChild(msg);
    } else {
      trayCards().forEach((c) => {
        const cardNode = cardEl(c);
        if (state.selectedCard === c) cardNode.classList.add('selected');
        cardNode.addEventListener('click', (ev) => {
          if (ev.metaKey || ev.ctrlKey) {
            placeInFirstOpenSlot(state.assignment, c, cap);
            state.selectedCard = null;
            renderGame();
            return;
          }
          state.selectedCard = state.selectedCard === c ? null : c;
          renderGame();
        });
        tray.appendChild(cardNode);
      });
    }

    document.querySelectorAll('#screen-game .slot').forEach((slotDiv) => {
      slotDiv.onclick = (ev) => {
        if (disabled) return;
        const slot = slotDiv.dataset.slot;
        if (!state.selectedCard) return;
        if (state.assignment[slot].length >= cap[slot]) return;
        state.assignment[slot].push(state.selectedCard);
        state.selectedCard = null;
        renderGame();
      };
    });

    const allPlaced = trayCards().length === 0
      && state.assignment.one.length === cap.one
      && state.assignment.two.length === cap.two
      && state.assignment.four.length === cap.four;
    el('btnLock').disabled = disabled || !allPlaced;
    el('btnClear').disabled = disabled;

    updateLockStatus();
  }

  function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  // ⌘/Ctrl+click a tray card to skip the select-then-click-a-slot dance — drops it
  // straight into the first slot (left to right: 1-card, 2-card, 4-card) that still has
  // room. No-ops if every slot is already full. Shared by the live game and Practice
  // Mode, each with their own separate assignment object.
  function placeInFirstOpenSlot(assignment, card, capacity = CAPACITY) {
    for (const slot of ['one', 'two', 'four']) {
      if (assignment[slot].length < capacity[slot]) {
        assignment[slot].push(card);
        return true;
      }
    }
    return false;
  }

  el('btnClear').addEventListener('click', () => {
    state.assignment = { one: [], two: [], four: [] };
    state.selectedCard = null;
    renderGame();
  });

  el('btnLock').addEventListener('click', async () => {
    const res = await api('/api/lock_hand', { code: state.code, playerId: state.playerId, token: state.token, assignment: state.assignment });
    if (!res.ok) {
      el('gameError').textContent = res.error;
      show('gameError');
      return;
    }
    hide('gameError');
    state.locked = true;
    renderGame();
  });

  function updateLockStatus() {
    if (!state.room) return;
    const players = state.room.players;
    const lockedCount = players.filter((p) => p.locked).length;
    el('lockStatus').textContent = `${lockedCount}/${players.length} locked`;

    // Who the table is actually waiting on. Without this a bot solving its hand looks
    // identical to a human who wandered off, which is exactly the moment the game feels
    // like it has hung.
    const strip = el('seatStatus');
    strip.innerHTML = '';
    players.forEach((p) => {
      const chip = document.createElement('span');
      const thinking = !!p.thinking && !p.locked;
      chip.className = 'seat-chip' + (p.locked ? ' locked' : thinking ? ' thinking' : '');

      const name = document.createElement('span');
      name.className = 'seat-name';
      name.textContent = p.name + (p.id === state.playerId ? ' (you)' : '');
      chip.appendChild(name);

      const status = document.createElement('span');
      status.className = 'seat-state';
      if (p.locked) {
        status.textContent = '✓';
      } else if (thinking) {
        const dots = document.createElement('span');
        dots.className = 'seat-dots';
        dots.innerHTML = '<i></i><i></i><i></i>';
        status.appendChild(dots);
        const word = document.createElement('span');
        word.className = 'seat-word';
        word.textContent = 'thinking';
        status.appendChild(word);
      } else {
        status.textContent = p.isBot ? 'waiting' : (p.connected ? 'arranging…' : 'offline');
      }
      chip.appendChild(status);
      strip.appendChild(chip);
    });
  }

  // ---------- results ----------
  // The full results payload arrives from the server all at once (nothing is hidden),
  // but we reveal it to the player as a staged, timed "sweat" sequence: hole cards are
  // shown first (like a showdown), then each board is run one at a time — cards land,
  // then what everyone made on that board is revealed, then every comparison for that
  // board is stepped through live with the point swing posted right on the hand it
  // came from. Total runtime targets ~15s for a heads-up hand and scales up naturally
  // for more players/comparisons. "Skip" jumps straight to the end state.
  const RESULTS_TARGET_MS = 15000;
  let revealState = null; // { timers: [], cancelled: false }

  function handleResults(results) {
    state.lastResults = results;
    hide('screen-game'); hide('screen-lobby');
    show('screen-results');
    startResultsReveal(results);
  }

  function clearRevealTimers() {
    if (revealState) {
      revealState.timers.forEach((t) => clearTimeout(t));
      revealState.cancelled = true;
    }
  }

  function runQueue(myRevealState, queue) {
    let i = 0;
    function step() {
      if (myRevealState.cancelled || i >= queue.length) return;
      const item = queue[i++];
      const t = setTimeout(() => {
        if (myRevealState.cancelled) return;
        item.run();
        step();
      }, item.delay);
      myRevealState.timers.push(t);
    }
    step();
  }

  function startResultsReveal(r) {
    clearRevealTimers();
    revealState = { timers: [], cancelled: false };
    const myRevealState = revealState;
    revealInProgress = true;

    el('resultsHandNumber').textContent = r.handNumber;
    hide('homerunBanner');
    el('homerunBanner').innerHTML = '';
    el('homerunBanner').classList.remove('reveal');
    el('boardsRow').innerHTML = '';
    el('resultsPlayers').innerHTML = '';
    el('scoreboard').innerHTML = '';
    el('scoreboard').classList.remove('card-reveal');
    el('comparisonLog').innerHTML = '';
    const logDetails = el('comparisonLog').closest('details');
    if (logDetails) logDetails.open = true;
    hide('btnNextHand');
    show('btnSkipReveal');
    el('revealStatus').textContent = 'Hands are in…';
    show('revealStatus');

    const nameById = {};
    r.players.forEach((p) => (nameById[p.id] = p.name));

    const queue = [];
    const runningPoints = {};
    const cellPoints = {};
    r.players.forEach((p) => { runningPoints[p.id] = 0; });

    // Stage 0: show everyone's hole cards, split into their 1/2/4 slots — before either
    // board is even shown, so you can feel out who has what to work with.
    r.players.forEach((p) => {
      queue.push({ delay: 450, run: () => appendPlayerSkeleton(r, p) });
    });

    // Stages 1-3, run once per board: reveal that board's cards, reveal what everyone
    // made on it, then step through that board's comparisons live with point swings
    // posted on the spot.
    function queueBoardStages(boardIdx, label) {
      const comparisonsForBoard = r.comparisons.filter((c) => c.boardIndex === boardIdx);

      queue.push({
        delay: 500,
        run: () => { el('revealStatus').textContent = `Revealing ${label}…`; ensureBoardBlock(boardIdx, label); }
      });
      r.boards[boardIdx].forEach((c) => {
        queue.push({ delay: 220, run: () => appendBoardCard(boardIdx, c) });
      });

      queue.push({ delay: 400, run: () => { el('revealStatus').textContent = `What's everyone making on ${label}?`; } });
      r.players.forEach((p) => {
        ['one', 'two', 'four'].forEach((cat) => {
          queue.push({ delay: 180, run: () => revealPlayerBoardHand(r, p, cat, boardIdx) });
        });
      });

      const nComp = Math.max(comparisonsForBoard.length, 1);
      const compDelay = Math.max(90, Math.min(500, Math.round(3200 / nComp)));
      queue.push({ delay: 450, run: () => { el('revealStatus').textContent = `Comparing ${label}…`; } });
      comparisonsForBoard.forEach((c) => {
        queue.push({
          delay: compDelay,
          run: () => {
            appendComparisonLine(c, nameById);
            if (c.winner) {
              const loser = c.winner === c.playerA ? c.playerB : c.playerA;
              runningPoints[c.winner] += c.points;
              runningPoints[loser] -= c.points;
              updatePlayerScore(c.winner, runningPoints[c.winner]);
              updatePlayerScore(loser, runningPoints[loser]);
              bumpCellPoints(cellPoints, c.winner, c.category, c.boardIndex, c.points);
              bumpCellPoints(cellPoints, loser, c.category, c.boardIndex, -c.points);
            }
          }
        });
      });
    }

    queueBoardStages(0, 'Board A');
    queueBoardStages(1, 'Board B');

    // Padding pause so the whole reveal lands close to RESULTS_TARGET_MS for a typical
    // heads-up hand, instead of feeling rushed — bigger hands (more players/comparisons)
    // naturally run longer on their own and just skip the padding.
    const flourishMs = 2200;
    const plannedSoFar = queue.reduce((sum, step) => sum + step.delay, 0);
    const pad = Math.max(0, RESULTS_TARGET_MS - plannedSoFar - flourishMs);
    if (pad > 0) {
      queue.push({ delay: pad, run: () => { el('revealStatus').textContent = 'Tallying final results…'; } });
    }

    // Final flourish — homerun banner (if any), then the finished scoreboard.
    const hasHomerun = !!(r.homeruns && r.homeruns.length > 0);
    queue.push({ delay: 500, run: () => { if (hasHomerun) showHomerunBanner(r, nameById); } });
    queue.push({ delay: hasHomerun ? 900 : 200, run: () => finishReveal(r) });

    runQueue(myRevealState, queue);
  }

  function ensureBoardBlock(boardIdx, label) {
    const block = document.createElement('div');
    block.className = 'board-block';
    const h = document.createElement('h4');
    h.textContent = label;
    block.appendChild(h);
    const cardsDiv = document.createElement('div');
    cardsDiv.className = 'board-cards';
    cardsDiv.id = 'boardCards' + boardIdx;
    block.appendChild(cardsDiv);
    el('boardsRow').appendChild(block);
  }

  function appendBoardCard(boardIdx, card) {
    const cardsDiv = el('boardCards' + boardIdx);
    const node = cardEl(card);
    node.classList.add('card-reveal');
    cardsDiv.appendChild(node);
  }

  // Stage 0: player's box with just their hole cards (1/2/4 slots), plus empty
  // pending placeholders for each board's eventual hand-type + points.
  function appendPlayerSkeleton(r, p) {
    const box = document.createElement('div');
    box.className = 'player-result card-reveal';
    box.id = 'playerResult-' + p.id;

    const head = document.createElement('div');
    head.className = 'player-result-head';
    head.id = 'playerHead-' + p.id;
    const pname = document.createElement('span');
    pname.className = 'pname';
    pname.textContent = p.name + (p.id === state.playerId ? ' (you)' : '');
    const pscore = document.createElement('span');
    pscore.id = 'pscore-' + p.id;
    pscore.className = 'pscore';
    pscore.textContent = '0 this hand';
    head.appendChild(pname);
    head.appendChild(pscore);
    box.appendChild(head);

    const preview = document.createElement('div');
    preview.className = 'hole-cards-preview';
    ['one', 'two', 'four'].forEach((cat) => {
      const group = document.createElement('span');
      group.className = 'hc-group';
      const lbl = document.createElement('span');
      lbl.className = 'hc-label';
      lbl.textContent = SLOT_TITLES[cat] + ':';
      group.appendChild(lbl);
      group.appendChild(cardRow(p.assignment[cat], { size: 'small' }));
      preview.appendChild(group);
    });
    box.appendChild(preview);

    ['one', 'two', 'four'].forEach((cat) => {
      const row = document.createElement('div');
      row.className = 'cat-row';

      const labelDiv = document.createElement('div');
      labelDiv.className = 'cat-label';
      labelDiv.textContent = SLOT_TITLES[cat];
      row.appendChild(labelDiv);

      [0, 1].forEach((boardIndex) => {
        const cell = document.createElement('div');
        cell.className = 'board-eval';
        cell.id = 'boardEval-' + p.id + '-' + cat + '-' + boardIndex;
        const catName = document.createElement('span');
        catName.className = 'cat-name pending';
        catName.textContent = (boardIndex === 0 ? 'Board A: ' : 'Board B: ') + '…';
        cell.appendChild(catName);
        const ptsBadge = document.createElement('span');
        ptsBadge.className = 'cell-points hidden';
        ptsBadge.id = 'cellPts-' + p.id + '-' + cat + '-' + boardIndex;
        cell.appendChild(ptsBadge);
        row.appendChild(cell);
      });

      box.appendChild(row);
    });

    el('resultsPlayers').appendChild(box);
  }

  // Stage 2: fill in what a player made in one category on one board, once that
  // board's cards are known — replaces the "…" placeholder with the real category
  // name and the highlighted cards that made it.
  function revealPlayerBoardHand(r, p, cat, boardIndex) {
    const evalInfo = r.evals[p.id][cat][boardIndex];
    const cell = el('boardEval-' + p.id + '-' + cat + '-' + boardIndex);
    if (!cell) return;
    const catName = cell.querySelector('.cat-name');
    catName.classList.remove('pending');
    catName.textContent = (boardIndex === 0 ? 'Board A: ' : 'Board B: ') + evalInfo.category;
    const usedSet = new Set(evalInfo.cards);
    const handCardsRow = cardRow(p.assignment[cat], { size: 'small' });
    [...handCardsRow.children].forEach((child, idx) => {
      if (usedSet.has(p.assignment[cat][idx])) child.classList.add('used-in-best');
    });
    cell.insertBefore(handCardsRow, cell.querySelector('.cell-points'));
    cell.classList.add('card-reveal');
  }

  function updatePlayerScore(id, pts) {
    const span = el('pscore-' + id);
    if (!span) return;
    span.className = 'pscore ' + (pts > 0 ? 'pos' : pts < 0 ? 'neg' : '');
    span.textContent = fmtSigned(pts) + ' this hand';
  }

  // Stage 3: post the point swing directly on the (player, category, board) cell it
  // came from, accumulating if that player has multiple opponents at the table.
  function bumpCellPoints(cellPoints, playerId, cat, boardIndex, delta) {
    cellPoints[playerId] = cellPoints[playerId] || {};
    cellPoints[playerId][cat] = cellPoints[playerId][cat] || {};
    const current = (cellPoints[playerId][cat][boardIndex] || 0) + delta;
    cellPoints[playerId][cat][boardIndex] = current;

    const badge = el('cellPts-' + playerId + '-' + cat + '-' + boardIndex);
    if (badge) {
      badge.classList.remove('hidden', 'flash');
      badge.textContent = fmtSigned(current);
      badge.className = 'cell-points ' + (current > 0 ? 'pos' : current < 0 ? 'neg' : 'even');
      void badge.offsetWidth; // restart the flash animation even if it fires again
      badge.classList.add('flash');
    }

    const cell = el('boardEval-' + playerId + '-' + cat + '-' + boardIndex);
    if (cell) {
      cell.classList.remove('cell-pos', 'cell-neg', 'cell-even');
      cell.classList.add(current > 0 ? 'cell-pos' : current < 0 ? 'cell-neg' : 'cell-even');
    }
  }

  function appendComparisonLine(c, nameById) {
    const log = el('comparisonLog');
    const boardLabel = c.boardIndex === 0 ? 'Board A' : 'Board B';
    const catLabel = SLOT_TITLES[c.category];
    const line = document.createElement('div');
    line.className = 'log-reveal';
    if (!c.winner) {
      line.classList.add('push');
      line.textContent = `${nameById[c.playerA]} vs ${nameById[c.playerB]} — ${catLabel} on ${boardLabel}: push (no points)`;
    } else {
      const loserName = c.winner === c.playerA ? nameById[c.playerB] : nameById[c.playerA];
      line.textContent = `${nameById[c.winner]} beat ${loserName} — ${catLabel} on ${boardLabel}: +${c.points}`;
    }
    log.appendChild(line);
    log.scrollTop = log.scrollHeight;
  }

  function showHomerunBanner(r, nameById) {
    const banner = el('homerunBanner');
    banner.textContent = '';
    r.homeruns.forEach((h, i) => {
      if (i > 0) banner.appendChild(document.createElement('br'));
      const loserId = h.winner === h.playerA ? h.playerB : h.playerA;
      const text = `⚾ ${nameById[h.winner]} hit a HOMERUN — swept all 6 comparisons (both boards) vs ${nameById[loserId]} (double points!)`;
      banner.appendChild(document.createTextNode(text));
    });
    banner.classList.remove('hidden');
    banner.classList.add('reveal');

    r.homeruns.forEach((h) => {
      const head = el('playerHead-' + h.winner);
      if (!head || head.querySelector('.homerun-tag')) return;
      const hrCount = r.homeruns.filter((hh) => hh.winner === h.winner).length;
      const tag = document.createElement('span');
      tag.className = 'homerun-tag';
      tag.textContent = `⚾ HOMERUN${hrCount > 1 ? ' x' + hrCount : ''}`;
      head.querySelector('.pname').after(tag);
    });

    if (r.homeruns.some((h) => h.winner === state.playerId)) playHomerunSound();
  }

  function finishReveal(r) {
    revealInProgress = false;
    hide('revealStatus');
    hide('btnSkipReveal');

    // Force every displayed score and per-cell point badge to the authoritative final
    // values — guards against any drift in the live running tally and guarantees the
    // numbers match the server exactly.
    r.players.forEach((p) => updatePlayerScore(p.id, r.pointsThisHand[p.id]));

    const table = el('scoreboard');
    const sorted = [...r.players].sort((a, b) => r.cumulative[b.id] - r.cumulative[a.id]);
    table.innerHTML = '<tr><th>Player</th><th>This Hand</th><th>Total</th></tr>' + sorted.map((p) => `
      <tr>
        <td>${escapeHtml(p.name)}${p.id === state.playerId ? ' (you)' : ''}</td>
        <td>${fmtSigned(r.pointsThisHand[p.id])}</td>
        <td><strong>${fmtSigned(r.cumulative[p.id])}</strong></td>
      </tr>
    `).join('');
    table.classList.add('card-reveal');

    // A homerun already got its own bigger fanfare (via showHomerunBanner, timed to the
    // banner appearing) — don't also play the plain win chime on top of that for the same
    // hand. Otherwise, a positive net score this hand gets the regular "you won" cue.
    const wonHomerun = !!(r.homeruns && r.homeruns.some((h) => h.winner === state.playerId));
    if (!wonHomerun && (r.pointsThisHand[state.playerId] || 0) > 0) playWinSound();

    const isHost = state.room && state.room.hostId === state.playerId;
    if (isHost) show('btnNextHand'); else hide('btnNextHand');
  }

  function fastForwardResults(r) {
    const nameById = {};
    r.players.forEach((p) => (nameById[p.id] = p.name));

    el('boardsRow').innerHTML = '';
    el('resultsPlayers').innerHTML = '';
    el('comparisonLog').innerHTML = '';

    r.players.forEach((p) => appendPlayerSkeleton(r, p));

    const cellPoints = {};
    [0, 1].forEach((boardIdx) => {
      const label = boardIdx === 0 ? 'Board A' : 'Board B';
      ensureBoardBlock(boardIdx, label);
      r.boards[boardIdx].forEach((c) => appendBoardCard(boardIdx, c));
      r.players.forEach((p) => {
        ['one', 'two', 'four'].forEach((cat) => revealPlayerBoardHand(r, p, cat, boardIdx));
      });
      r.comparisons.filter((c) => c.boardIndex === boardIdx).forEach((c) => {
        appendComparisonLine(c, nameById);
        if (c.winner) {
          const loser = c.winner === c.playerA ? c.playerB : c.playerA;
          bumpCellPoints(cellPoints, c.winner, c.category, c.boardIndex, c.points);
          bumpCellPoints(cellPoints, loser, c.category, c.boardIndex, -c.points);
        }
      });
    });

    const hasHomerun = !!(r.homeruns && r.homeruns.length > 0);
    if (hasHomerun) showHomerunBanner(r, nameById); else hide('homerunBanner');

    finishReveal(r);
  }

  function fmtSigned(n) { return (n > 0 ? '+' : '') + n; }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
  }

  el('btnSkipReveal').addEventListener('click', () => {
    if (!state.lastResults) return;
    clearRevealTimers();
    fastForwardResults(state.lastResults);
  });

  el('btnNextHand').addEventListener('click', async () => {
    const res = await api('/api/next_hand', { code: state.code, playerId: state.playerId, token: state.token });
    if (res && !res.ok) alert(res.error);
  });

  // ---------- practice mode ----------
  // Entirely client-side after the initial pool fetch: no server round-trip per redo.
  // The "opponent" for each trial is a (hand, split) pair pulled from opponent-pool.json —
  // hands whose blind split was solved offline via the iterative best-response bootstrap
  // documented in experiments/solve/. Re-arranging your own hand re-scores instantly
  // against the SAME set of trials, so EV differences between your attempts are directly
  // comparable (no fresh variance each redo).
  const PRACTICE_TRIALS_MIN = 100;
  const PRACTICE_TRIALS_MAX = 10000;
  const PRACTICE_TRIALS_DEFAULT = 500;
  let practiceTrialTarget = PRACTICE_TRIALS_DEFAULT; // takes effect on the next dealt hand

  // The board-count slider is logarithmic (100 to 10,000 spans two orders of magnitude —
  // a linear slider would waste almost all of its travel on the 1000-10000 range and make
  // it nearly impossible to land precisely on, say, 200). The <input type="range"> itself
  // stays a plain linear control internally (0..PRACTICE_SLIDER_STEPS); these two helpers
  // convert between that raw position and an actual trial count, snapped to a clean-ish
  // number so the displayed value doesn't look like random noise (e.g. "2340" not "2337").
  const PRACTICE_SLIDER_STEPS = 1000;
  function practiceSliderToTrials(raw) {
    const t = Math.min(1, Math.max(0, raw / PRACTICE_SLIDER_STEPS));
    const logMin = Math.log10(PRACTICE_TRIALS_MIN);
    const logMax = Math.log10(PRACTICE_TRIALS_MAX);
    const exact = Math.pow(10, logMin + t * (logMax - logMin));
    let snapped;
    if (exact < 1000) snapped = Math.round(exact / 10) * 10;
    else if (exact < 3000) snapped = Math.round(exact / 50) * 50;
    else snapped = Math.round(exact / 100) * 100;
    return Math.min(PRACTICE_TRIALS_MAX, Math.max(PRACTICE_TRIALS_MIN, snapped));
  }
  function practiceTrialsToSlider(trials) {
    const logMin = Math.log10(PRACTICE_TRIALS_MIN);
    const logMax = Math.log10(PRACTICE_TRIALS_MAX);
    const t = (Math.log10(trials) - logMin) / (logMax - logMin);
    return Math.round(t * PRACTICE_SLIDER_STEPS);
  }

  // "Show Ideal Split" has its own separate board-count slider (same 100-10,000 log range
  // and the same helpers above) instead of always riding on the EV panel's slider — the
  // ideal split search is far more expensive per board (105 partitions vs. 1), so someone
  // running 10,000 boards through the EV panel usually still wants the search itself to
  // stay fast, but they can dial it up if they want a slower, more precise search. It's
  // sticky (unlike the EV slider, it applies immediately, not just on New Hand) and gets
  // clamped down to however many boards this hand actually has if set higher than that.
  // Matches the EV panel's default: the search is clamped to the hand's own boards so
  // its EV is directly comparable to yours, and defaulting higher would mean the clamp
  // note fired on every single hand.
  const PRACTICE_IDEAL_TRIALS_DEFAULT = 500;
  let practiceIdealTrialTarget = PRACTICE_IDEAL_TRIALS_DEFAULT;

  // Homerun scoring is always part of the game now, so Practice Mode's EV calculations
  // and the ideal-split search always factor it in too — there's no toggle for it.
  const practiceHomerunMode = true;
  const PRACTICE_POINTS = { one: 1, two: 2, four: 3 };
  let opponentPool = null; // cached after first fetch
  let practice = null; // { hand, trials, assignment, selectedCard, saved: [] }

  async function loadOpponentPool() {
    if (opponentPool) return opponentPool;
    const res = await fetch('/opponent-pool.json');
    opponentPool = await res.json();
    return opponentPool;
  }

  function shuffleArray(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function buildPracticeTrials(playerHand, pool, trialCount) {
    const playerSet = new Set(playerHand);
    const qualifying = pool.filter((entry) => {
      const oppHand = [...entry.one, ...entry.two, ...entry.four];
      return oppHand.every((c) => !playerSet.has(c));
    });

    let chosen;
    if (qualifying.length >= trialCount) {
      chosen = shuffleArray(qualifying).slice(0, trialCount);
    } else {
      // The pre-solved opponent pool has ~5400 hands total, and roughly a third of those
      // qualify (don't share a card with yours) for any given hand — about 1800 distinct
      // opponents, so the default 150 boards and the ideal-split search's default 1000 both
      // draw a fresh opponent every trial. Past ~1800 opponents start repeating (with fresh
      // boards each trial). Still zero risk of a duplicate card within any single trial.
      chosen = [];
      for (let i = 0; i < trialCount; i++) {
        chosen.push(qualifying[Math.floor(Math.random() * qualifying.length)] || pool[i % pool.length]);
      }
    }

    return chosen.map((entry) => {
      const oppHand = [...entry.one, ...entry.two, ...entry.four];
      const oppSet = new Set([...playerHand, ...oppHand]);
      const remaining = shuffleArray(window.Poker.freshDeck().filter((c) => !oppSet.has(c)));
      const boardA = remaining.slice(0, 5);
      const boardB = remaining.slice(5, 10);
      return { oppSplit: entry, boardA, boardB };
    });
  }

  async function startPractice() {
    hide('screen-landing');
    show('screen-practice');
    el('practiceEvPanel').classList.add('hidden');
    el('practiceSlots').querySelectorAll('.slot-cards').forEach((n) => (n.innerHTML = ''));
    el('pTray').innerHTML = '<div class="hint">Loading opponent pool…</div>';

    const pool = await loadOpponentPool();
    renderHandFilterCount();
    // Explore deals from the pool too (not a raw shuffle) so the hand filter applies here
    // as well, and so the hand's own solved EV is known. Pool hands are themselves random
    // 7-card hands, so with no filter this is the same distribution as before.
    const usable = filteredPool(pool);
    const seed = usable[Math.floor(Math.random() * usable.length)];
    const hand = [...seed.one, ...seed.two, ...seed.four];
    const trials = buildPracticeTrials(hand, pool, practiceTrialTarget);

    practice = {
      hand,
      solvedEv: typeof seed.ev === 'number' ? seed.ev : null,
      trials,
      assignment: { one: [], two: [], four: [] },
      selectedCard: null,
      saved: [],
      ideal: null
    };
    el('practiceIdealPanel').classList.add('hidden');
    const idealBtn = el('btnPracticeIdeal');
    idealBtn.disabled = false;
    idealBtn.textContent = 'Show Ideal Split';
    renderPracticeArranger();
    renderPracticeSaved();
    renderPracticeSolvedEv();
  }

  function practiceTrayCards() {
    const used = new Set([...practice.assignment.one, ...practice.assignment.two, ...practice.assignment.four]);
    return sortCards(practice.hand.filter((c) => !used.has(c)), cardSortMode);
  }

  function renderPracticeArranger() {
    hide('practiceError');
    ['one', 'two', 'four'].forEach((slot) => {
      const container = el('pSlot' + capitalize(slot));
      container.innerHTML = '';
      practice.assignment[slot].forEach((c) => {
        const cardNode = cardEl(c);
        cardNode.addEventListener('click', () => {
          practice.assignment[slot] = practice.assignment[slot].filter((x) => x !== c);
          practice.selectedCard = null;
          renderPracticeArranger();
        });
        container.appendChild(cardNode);
      });
    });

    const tray = el('pTray');
    tray.innerHTML = '';
    practiceTrayCards().forEach((c) => {
      const cardNode = cardEl(c);
      if (practice.selectedCard === c) cardNode.classList.add('selected');
      cardNode.addEventListener('click', (ev) => {
        if (ev.metaKey || ev.ctrlKey) {
          placeInFirstOpenSlot(practice.assignment, c);
          practice.selectedCard = null;
          renderPracticeArranger();
          return;
        }
        practice.selectedCard = practice.selectedCard === c ? null : c;
        renderPracticeArranger();
      });
      tray.appendChild(cardNode);
    });

    document.querySelectorAll('#practiceSlots .slot').forEach((slotDiv) => {
      slotDiv.onclick = () => {
        const slot = slotDiv.dataset.slot;
        if (!practice.selectedCard) return;
        if (practice.assignment[slot].length >= CAPACITY[slot]) return;
        practice.assignment[slot].push(practice.selectedCard);
        practice.selectedCard = null;
        renderPracticeArranger();
      };
    });

    const complete = practiceTrayCards().length === 0
      && practice.assignment.one.length === 1
      && practice.assignment.two.length === 2
      && practice.assignment.four.length === 4;
    el('btnPracticeSave').disabled = !complete;

    if (complete) {
      runPracticeEval();
    } else {
      el('practiceEvPanel').classList.add('hidden');
    }
  }

  el('btnPracticeClear').addEventListener('click', () => {
    if (!practice) return;
    practice.assignment = { one: [], two: [], four: [] };
    practice.selectedCard = null;
    renderPracticeArranger();
  });

  function evalHandOnBoard(cards, board, cat) {
    return cat === 'four' ? window.Poker.bestPLO(cards, board) : window.Poker.bestGeneric(cards, board);
  }

  // Matches lib/game.js's rule exactly: sweeping all 6 comparisons against this one
  // opponent (both boards, all 3 hand sizes, no ties anywhere) doubles the match total
  // for that trial, 12 -> 24 (or -24 if you're the one swept). The opponent's split in
  // opponent-pool.json is itself solved for this same homerun rule (see
  // experiments/solve/solve_round_hr.js and solve_fixed_hr.js) — not a standard-rules
  // opponent that just happens to get scored with the bonus on top.
  const PRACTICE_MATCH_TOTAL = (PRACTICE_POINTS.one + PRACTICE_POINTS.two + PRACTICE_POINTS.four) * 2;

  // Score `assignment` against one trial's fixed opponent + boards. Returns the point
  // swing for each of the 6 (category, board) cells, the total, and whether this trial
  // was a homerun (for either side) once homerunMode's bonus is folded in.
  function scoreTrial(assignment, trial, homerunMode) {
    const cells = { one: [0, 0], two: [0, 0], four: [0, 0] };
    let total = 0;
    let allWon = true;
    let allLost = true;
    ['one', 'two', 'four'].forEach((cat) => {
      [trial.boardA, trial.boardB].forEach((board, bi) => {
        const mine = evalHandOnBoard(assignment[cat], board, cat);
        const theirs = evalHandOnBoard(trial.oppSplit[cat], board, cat);
        const cmp = window.Poker.compareScores(mine.score, theirs.score);
        const pts = PRACTICE_POINTS[cat];
        const delta = cmp > 0 ? pts : cmp < 0 ? -pts : 0;
        cells[cat][bi] = delta;
        total += delta;
        if (delta <= 0) allWon = false;
        if (delta >= 0) allLost = false;
      });
    });
    let homerun = null;
    if (homerunMode) {
      if (allWon) { total += PRACTICE_MATCH_TOTAL; homerun = 'win'; }
      else if (allLost) { total -= PRACTICE_MATCH_TOTAL; homerun = 'loss'; }
    }
    return { total, cells, homerun };
  }

  // Runs the current arrangement through all trials — cheap, pure client-side
  // evaluate5() calls, no network — so this can fire on every completed arrangement.
  // Also tracks the sum of squares of the per-hand total so it can report the variance
  // and standard deviation of the outcome (how swingy this split's results are trial to
  // trial), plus the standard error of the EV estimate itself — i.e. roughly how far off
  // "avgTotal" might be from the true long-run EV, given only `n` trials.
  function evalAssignmentAcrossTrials(assignment, trials, homerunMode, opts) {
    let sumTotal = 0;
    let sumTotalSq = 0;
    // Optionally keep each trial's own result. Two splits scored on the SAME boards are a
    // paired sample, and the spread of their per-board differences is far smaller than
    // either split's own spread — so this is what makes "is A really better than B?"
    // answerable, rather than comparing two noisy averages.
    const perTrial = opts && opts.keepPerTrial ? new Float64Array(trials.length) : null;
    let ti = 0;
    const sumCells = { one: [0, 0], two: [0, 0], four: [0, 0] };
    let homerunWins = 0;
    let homerunLosses = 0;
    trials.forEach((trial) => {
      const r = scoreTrial(assignment, trial, homerunMode);
      if (perTrial) perTrial[ti] = r.total;
      ti++;
      sumTotal += r.total;
      sumTotalSq += r.total * r.total;
      ['one', 'two', 'four'].forEach((cat) => {
        sumCells[cat][0] += r.cells[cat][0];
        sumCells[cat][1] += r.cells[cat][1];
      });
      if (r.homerun === 'win') homerunWins++;
      else if (r.homerun === 'loss') homerunLosses++;
    });
    const n = trials.length;
    const avgCells = {};
    ['one', 'two', 'four'].forEach((cat) => {
      avgCells[cat] = [sumCells[cat][0] / n, sumCells[cat][1] / n];
    });
    const avgTotal = sumTotal / n;
    // Sample variance (n-1 denominator); guard the n===1 edge case.
    const varianceTotal = n > 1 ? Math.max(0, (sumTotalSq - n * avgTotal * avgTotal) / (n - 1)) : 0;
    const sdTotal = Math.sqrt(varianceTotal);
    const seTotal = n > 0 ? sdTotal / Math.sqrt(n) : 0;
    return { avgTotal, avgCells, homerunWins, homerunLosses, n, varianceTotal, sdTotal, seTotal, perTrial };
  }

  function fmtEv(n) { return (n > 0 ? '+' : '') + n.toFixed(2); }

  function runPracticeEval() {
    const result = evalAssignmentAcrossTrials(practice.assignment, practice.trials, practiceHomerunMode, { keepPerTrial: true });
    practice.lastEv = result;
    renderPracticeEV(result);
  }

  function renderPracticeSolvedEv() {
    const node = el('practiceSolvedEv');
    if (!node) return;
    if (!practice || practice.solvedEv === null) { node.classList.add('hidden'); return; }
    const ev = practice.solvedEv;
    node.innerHTML = `This hand's solved value: <strong class="${ev > 0 ? 'pos' : ev < 0 ? 'neg' : ''}">${fmtEv(ev)}</strong> pts/hand `
      + `<span class="hint-inline">— what the solver's own split for these cards is worth against the field</span>`;
    node.classList.remove('hidden');
  }

  function renderPracticeEV(result) {
    const { avgTotal, avgCells, homerunWins, homerunLosses, n, varianceTotal, sdTotal, seTotal } = result;
    el('practiceTrialCount').textContent = practice.trials.length;
    const totalSpan = el('practiceEvTotal');
    totalSpan.textContent = fmtEv(avgTotal);
    totalSpan.className = 'pscore ' + (avgTotal > 0 ? 'pos' : avgTotal < 0 ? 'neg' : '');

    // Just for fun / for the curious: how swingy is this split's outcome trial-to-trial
    // (variance / SD of the per-hand total), and how precise is the EV number above given
    // only `n` trials (standard error of the mean — roughly, the true EV is within about
    // +/-2*SE of avgTotal, 95% of the time).
    const varLine = el('practiceVarianceLine');
    if (varLine) {
      varLine.textContent =
        `\u{1F4CA} Variance: ${varianceTotal.toFixed(2)} pts² (SD ±${sdTotal.toFixed(2)} pts/hand) ` +
        `· this EV estimate is accurate to roughly ±${seTotal.toFixed(3)} (1 SE) over ${n.toLocaleString()} boards`;
    }

    const breakdown = el('practiceEvBreakdown');
    breakdown.innerHTML = '';
    ['one', 'two', 'four'].forEach((cat) => {
      const row = document.createElement('div');
      row.className = 'pcat-row';
      const label = document.createElement('div');
      label.className = 'pcat-label';
      label.textContent = SLOT_TITLES[cat];
      row.appendChild(label);
      [0, 1].forEach((bi) => {
        const v = avgCells[cat][bi];
        const cell = document.createElement('div');
        cell.innerHTML = `<span class="pcell-sub">${bi === 0 ? 'Board A' : 'Board B'}: </span><span class="pcell ${v > 0 ? 'pos' : v < 0 ? 'neg' : 'even'}">${fmtEv(v)}</span>`;
        row.appendChild(cell);
      });
      breakdown.appendChild(row);
    });

    const hrLine = el('practiceHomerunRate');
    if (n) {
      hrLine.innerHTML = `⚾ Homerun rate: you swept <span class="pcell pos">${homerunWins}/${n}</span> boards &middot; opponent swept <span class="pcell neg">${homerunLosses}/${n}</span> boards`;
      hrLine.classList.remove('hidden');
    } else {
      hrLine.classList.add('hidden');
    }

    el('practiceEvPanel').classList.remove('hidden');
  }

  // ---------- practice mode: "Show Ideal Split" ----------
  // Scores all 105 ways to split the 7 practice cards against the same trial set used
  // everywhere else in this session, and returns the best (plus 2 runner-ups). The work
  // happens in scorePartitionsAsync above.
  function allPartitions(cards) {
    const partitions = [];
    const oneCombos = window.Poker.combinations(cards, 1);
    for (const one of oneCombos) {
      const rest6 = cards.filter((c) => !one.includes(c));
      const twoCombos = window.Poker.combinations(rest6, 2);
      for (const two of twoCombos) {
        const four = rest6.filter((c) => !two.includes(c));
        partitions.push({ one, two, four });
      }
    }
    return partitions;
  }


  // Scores all 105 partitions and returns the best, plus the two runners-up.
  //
  // This used to be a successive-halving race — score everything for 200 boards, keep the
  // top 10, then the top 3 — because a flat search cost `boards x 105` hand evaluations and
  // took the better part of a minute at high board counts. That made it a heuristic: a
  // split that got unlucky early was eliminated for good. The table-based scorer removed
  // the reason for it, so this is now an exact exhaustive search over every partition and
  // every board, and the answer is the true best of the 105 on the boards you ran.
  function findIdealSplitAsync(hand, trials, homerunMode, onProgress) {
    return scorePartitionsAsync(allPartitions(hand), trials, onProgress).then((ranked) => {
      const top3 = ranked.slice(0, 3);
      // No need to re-score the winner through evalAssignmentAcrossTrials: that path and
      // this one are verified to produce bit-identical EVs, and re-deriving three splits
      // over every board again was costing more than the entire search.
      return {
        assignment: top3[0].assignment,
        avgTotal: top3[0].ev,
        n: trials.length,
        runnersUp: top3.slice(1).map((entry) => ({ assignment: entry.assignment, avgTotal: entry.ev }))
      };
    });
  }

  function renderPracticeIdeal(ideal) {
    const cardsWrap = el('practiceIdealCards');
    cardsWrap.innerHTML = '';
    const catShortLabel = { one: '1-Card:', two: '2-Card:', four: '4-Card:' };
    ['one', 'two', 'four'].forEach((cat) => {
      const group = document.createElement('span');
      group.className = 'hc-group';
      const lbl = document.createElement('span');
      lbl.className = 'hc-label';
      lbl.textContent = catShortLabel[cat];
      group.appendChild(lbl);
      group.appendChild(cardRow(ideal.assignment[cat], { size: 'small' }));
      cardsWrap.appendChild(group);
    });

    const evSpan = el('practiceIdealEv');
    evSpan.textContent = fmtEv(ideal.avgTotal);
    evSpan.className = 'pscore ' + (ideal.avgTotal > 0 ? 'pos' : ideal.avgTotal < 0 ? 'neg' : '');

    // The search runs against however many boards the "Ideal split search boards" slider
    // asked for, clamped down to however many this hand actually has (from the main EV
    // slider at deal time). Make that explicit whenever the clamp actually kicked in —
    // otherwise "Average EV" here and the EV panel's own number are silently over
    // different-sized (if overlapping) trial sets.
    const noteEl = el('practiceIdealTrialNote');
    if (noteEl) {
      if (ideal.n < practice.trials.length) {
        noteEl.textContent = `(checked against ${ideal.n.toLocaleString()} of your ${practice.trials.length.toLocaleString()} boards, per the search slider below)`;
      } else {
        noteEl.textContent = '(checked against these same boards)';
      }
    }

    renderPracticeRunnersUp(ideal.runnersUp || []);

    el('practiceIdealPanel').classList.remove('hidden');
  }

  // Renders the 2nd- and 3rd-place partitions inside a collapsed <details> — off by
  // default so it doesn't clutter the panel, but there for anyone curious how close the
  // field was (a clear standout winner vs. a virtual tie with a couple of alternatives).
  function renderPracticeRunnersUp(runnersUp) {
    const list = el('practiceRunnerUps');
    if (!list) return;
    list.innerHTML = '';
    const catShortLabel = { one: '1-Card:', two: '2-Card:', four: '4-Card:' };
    runnersUp.forEach((ru, i) => {
      const item = document.createElement('div');
      item.className = 'practice-runnerup-item';

      const rank = document.createElement('div');
      rank.className = 'practice-runnerup-rank';
      rank.textContent = `#${i + 2}`;
      item.appendChild(rank);

      const cardsWrap = document.createElement('div');
      cardsWrap.className = 'practice-ideal-cards';
      ['one', 'two', 'four'].forEach((cat) => {
        const group = document.createElement('span');
        group.className = 'hc-group';
        const lbl = document.createElement('span');
        lbl.className = 'hc-label';
        lbl.textContent = catShortLabel[cat];
        group.appendChild(lbl);
        group.appendChild(cardRow(ru.assignment[cat], { size: 'small' }));
        cardsWrap.appendChild(group);
      });
      item.appendChild(cardsWrap);

      const footer = document.createElement('div');
      footer.className = 'practice-ideal-footer';
      const evSpan = document.createElement('span');
      evSpan.innerHTML = `Average EV: <span class="pscore ${ru.avgTotal > 0 ? 'pos' : ru.avgTotal < 0 ? 'neg' : ''}">${fmtEv(ru.avgTotal)}</span> pts/hand`;
      footer.appendChild(evSpan);
      const loadBtn = document.createElement('button');
      loadBtn.className = 'secondary';
      loadBtn.textContent = 'Load This Split';
      loadBtn.addEventListener('click', () => {
        if (!practice) return;
        practice.assignment = deepCopy(ru.assignment);
        practice.selectedCard = null;
        renderPracticeArranger();
      });
      footer.appendChild(loadBtn);
      item.appendChild(footer);

      list.appendChild(item);
    });
  }

  el('btnPracticeIdeal').addEventListener('click', async () => {
    if (!practice) return;
    if (practice.ideal) { renderPracticeIdeal(practice.ideal); return; }

    const btn = el('btnPracticeIdeal');
    btn.disabled = true;
    btn.textContent = 'Calculating… 0%';
    const idealTrials = practice.trials.length > practiceIdealTrialTarget
      ? practice.trials.slice(0, practiceIdealTrialTarget)
      : practice.trials;
    practice.ideal = await findIdealSplitAsync(practice.hand, idealTrials, practiceHomerunMode, (frac) => {
      btn.textContent = `Calculating… ${Math.round(frac * 100)}%`;
    });
    btn.disabled = false;
    btn.textContent = 'Show Ideal Split';
    renderPracticeIdeal(practice.ideal);
  });

  el('btnPracticeLoadIdeal').addEventListener('click', () => {
    if (!practice || !practice.ideal) return;
    practice.assignment = deepCopy(practice.ideal.assignment);
    practice.selectedCard = null;
    renderPracticeArranger();
  });

  el('btnPracticeSave').addEventListener('click', () => {
    if (!practice || !practice.lastEv) return;
    const key = fmtAssignmentKey(practice.assignment);
    if (practice.saved.some((s) => s.key === key)) {
      el('practiceError').textContent = "You've already saved this exact split.";
      show('practiceError');
      return;
    }
    hide('practiceError');
    practice.saved.push({
      key,
      assignment: deepCopy(practice.assignment),
      avgTotal: practice.lastEv.avgTotal,
      avgCells: practice.lastEv.avgCells,
      perTrial: practice.lastEv.perTrial
    });
    renderPracticeSaved();
  });

  function fmtAssignmentKey(a) {
    return ['one', 'two', 'four'].map((c) => c + ':' + [...a[c]].sort().join(',')).join('|');
  }

  // Paired comparison of two splits scored on the same boards. Because the boards are
  // shared, most of the variance cancels: what matters is the spread of the per-board
  // DIFFERENCE, not each split's own spread. Returns the mean gap and its standard error,
  // plus whether the gap clears two standard errors (~95%) — i.e. whether the boards you
  // ran can actually tell these two splits apart.
  function pairedComparison(a, b) {
    if (!a || !b || !a.perTrial || !b.perTrial) return null;
    const n = Math.min(a.perTrial.length, b.perTrial.length);
    if (n < 2) return null;
    let sum = 0;
    for (let i = 0; i < n; i++) sum += a.perTrial[i] - b.perTrial[i];
    const mean = sum / n;
    let sq = 0;
    for (let i = 0; i < n; i++) {
      const d = (a.perTrial[i] - b.perTrial[i]) - mean;
      sq += d * d;
    }
    const sd = Math.sqrt(sq / (n - 1));
    const se = sd / Math.sqrt(n);
    return { mean, se, n, separated: Math.abs(mean) > 2 * se };
  }

  function renderPracticeSaved() {
    const list = el('practiceSaved');
    list.innerHTML = '';
    if (!practice || practice.saved.length === 0) {
      show('practiceSavedEmpty');
      return;
    }
    hide('practiceSavedEmpty');

    const sorted = [...practice.saved].sort((a, b) => b.avgTotal - a.avgTotal);
    sorted.forEach((s, i) => {
      const item = document.createElement('div');
      item.className = 'practice-saved-item' + (i === 0 ? ' best' : '');

      const rank = document.createElement('div');
      rank.className = 'psi-rank';
      rank.textContent = '#' + (i + 1);
      item.appendChild(rank);

      const cardsWrap = document.createElement('div');
      cardsWrap.className = 'psi-cards';
      const catShortLabel = { one: '1:', two: '2:', four: '4:' };
      ['one', 'two', 'four'].forEach((cat) => {
        const group = document.createElement('span');
        group.className = 'psi-group';
        const lbl = document.createElement('span');
        lbl.className = 'hc-label';
        lbl.textContent = catShortLabel[cat];
        group.appendChild(lbl);
        group.appendChild(cardRow(s.assignment[cat], { size: 'small' }));
        cardsWrap.appendChild(group);
      });
      item.appendChild(cardsWrap);

      const ev = document.createElement('div');
      ev.className = 'psi-ev ' + (s.avgTotal > 0 ? 'pos' : s.avgTotal < 0 ? 'neg' : '');
      ev.textContent = fmtEv(s.avgTotal) + ' EV';
      item.appendChild(ev);

      // How this split compares with the current leader, on the boards you actually ran.
      if (i > 0) {
        const cmp = pairedComparison(sorted[0], s);
        if (cmp) {
          const gap = document.createElement('div');
          gap.className = 'psi-gap' + (cmp.separated ? '' : ' tossup');
          gap.textContent = cmp.separated
            ? `#1 by ${cmp.mean.toFixed(2)} ± ${cmp.se.toFixed(2)}`
            : `too close to call (${cmp.mean.toFixed(2)} ± ${cmp.se.toFixed(2)})`;
          gap.title = cmp.separated
            ? `Measured on the same ${cmp.n.toLocaleString()} boards. The gap is more than twice its standard error, so it is unlikely to be noise.`
            : `Measured on the same ${cmp.n.toLocaleString()} boards. The gap is smaller than twice its standard error — deal more boards per split to separate these.`;
          item.appendChild(gap);
        }
      }

      const actions = document.createElement('div');
      actions.className = 'psi-actions';
      const loadBtn = document.createElement('button');
      loadBtn.textContent = 'Load';
      loadBtn.addEventListener('click', () => {
        practice.assignment = deepCopy(s.assignment);
        practice.selectedCard = null;
        renderPracticeArranger();
      });
      const removeBtn = document.createElement('button');
      removeBtn.textContent = 'Remove';
      removeBtn.addEventListener('click', () => {
        practice.saved = practice.saved.filter((x) => x.key !== s.key);
        renderPracticeSaved();
      });
      actions.appendChild(loadBtn);
      actions.appendChild(removeBtn);
      item.appendChild(actions);

      list.appendChild(item);
    });
  }

  el('btnPracticeStart').addEventListener('click', () => {
    hide('screen-landing');
    show('screen-practice');
    setPracticeMode('explore');
  });
  el('btnPracticeNewHand').addEventListener('click', () => { startPractice(); });
  el('btnPracticeBack').addEventListener('click', () => {
    rapid = null;
    practiceMode = 'explore';
    hide('screen-practice');
    show('screen-landing');
  });
  document.querySelectorAll('#practiceModeRow .rapid-mode-btn').forEach((btn) => {
    btn.addEventListener('click', () => setPracticeMode(btn.dataset.practiceMode));
  });
  el('handFilterSelect').addEventListener('change', () => {
    applyHandFilterUi();
    // a changed filter only takes effect on the next hand, so say so rather than
    // silently leaving the current one in place
    if (practiceMode === 'explore') startPractice();
    else if (rapid && PRACTICE_DRILLS.includes(practiceMode)) {
      rapid.next = null;
      rapidNext();
    }
  });
  ['handFilterMin', 'handFilterMax'].forEach((id) => {
    el(id).addEventListener('change', () => {
      applyHandFilterUi();
      if (practiceMode === 'explore') startPractice();
      else if (rapid && PRACTICE_DRILLS.includes(practiceMode)) { rapid.next = null; rapidNext(); }
    });
  });

  // The slider element itself is a plain linear <input type="range"> — its raw value is
  // a position (0..PRACTICE_SLIDER_STEPS), not a trial count. Set its bounds/initial
  // position here (rather than hardcoding a "nice" HTML default attribute) so it stays in
  // sync with PRACTICE_TRIALS_MIN/MAX/DEFAULT if those ever change.
  const trialsRangeEl = el('practiceTrialsRange');
  trialsRangeEl.min = 0;
  trialsRangeEl.max = PRACTICE_SLIDER_STEPS;
  trialsRangeEl.step = 1;
  trialsRangeEl.value = practiceTrialsToSlider(practiceTrialTarget);
  el('practiceTrialsValue').textContent = practiceTrialTarget.toLocaleString();
  el('practiceHintTrials').textContent = practiceTrialTarget.toLocaleString();

  trialsRangeEl.addEventListener('input', () => {
    practiceTrialTarget = practiceSliderToTrials(Number(trialsRangeEl.value));
    el('practiceTrialsValue').textContent = practiceTrialTarget.toLocaleString();
    el('practiceHintTrials').textContent = practiceTrialTarget.toLocaleString();
  });

  // Same log-scale setup, for the separate "Ideal split search boards" slider. Unlike the
  // EV slider above, changing this doesn't require a New Hand — it just invalidates any
  // cached ideal-split answer so the next "Show Ideal Split" click recomputes at the new
  // count.
  const idealTrialsRangeEl = el('practiceIdealTrialsRange');
  if (idealTrialsRangeEl) {
    idealTrialsRangeEl.min = 0;
    idealTrialsRangeEl.max = PRACTICE_SLIDER_STEPS;
    idealTrialsRangeEl.step = 1;
    idealTrialsRangeEl.value = practiceTrialsToSlider(practiceIdealTrialTarget);
    el('practiceIdealTrialsValue').textContent = practiceIdealTrialTarget.toLocaleString();

    idealTrialsRangeEl.addEventListener('input', () => {
      practiceIdealTrialTarget = practiceSliderToTrials(Number(idealTrialsRangeEl.value));
      el('practiceIdealTrialsValue').textContent = practiceIdealTrialTarget.toLocaleString();
      if (practice) {
        practice.ideal = null;
        el('practiceIdealPanel').classList.add('hidden');
        const idealBtn = el('btnPracticeIdeal');
        idealBtn.disabled = false;
        idealBtn.textContent = 'Show Ideal Split';
      }
    });
  }

  // ---------- shared room state ----------
  function handleRoomState(room) {
    state.room = room;
    if (room.phase === 'lobby') {
      enterLobby();
      renderLobby(room);
    } else if (room.phase === 'arranging') {
      // Keep the header honest even if a state update lands after the screen was rendered.
      el('handNumber').textContent = room.handNumber;
      updateLockStatus();
    } else if (room.phase === 'results') {
      if (revealInProgress) return; // don't let a late room_state event show the button mid-reveal
      const isHost = room.hostId === state.playerId;
      if (isHost) show('btnNextHand'); else hide('btnNextHand');
    }
  }

  // Wire up every "Sort: Dealt / Rank / Suit" control on the page. Each one re-renders
  // only its own screen — renderGame/renderPracticeArranger are each guarded internally
  // against running before that screen has real state to show, and since a hidden
  // screen's buttons can't be clicked (`.hidden` is display:none), the right one always
  // fires.
  wireSortControl('gameSortControl', renderGame);
  wireSortControl('practiceSortControl', renderPracticeArranger);

  // ---------- practice: one screen, five modes ----------
  // Explore is the original free-play mode (arrange, see EV, hunt the ideal split, save and
  // compare). Arrange / Estimate EV / Locked NLH are the graded drills, and Mistakes is
  // their shared retry list. They all deal from the same pool and obey the same hand
  // filter, which is why they belong together rather than behind separate menu entries.
  let practiceMode = 'explore';
  const PRACTICE_MODE_CAPTIONS = {
    explore: '— free play: arrange, price it, hunt the best split',
    arrange: '— drill: build the highest-EV split',
    estimate: '— drill: price each hand you build',
    locked: '— drill: the NLH hand is fixed, maximise the rest',
    mistakes: '— hands you misplayed, ready to re-drill'
  };
  const PRACTICE_DRILLS = ['arrange', 'estimate', 'locked'];

  function setPracticeMode(mode) {
    practiceMode = mode;
    const isDrill = PRACTICE_DRILLS.includes(mode);
    el('practiceExplore').classList.toggle('hidden', mode !== 'explore');
    el('practiceDrill').classList.toggle('hidden', !isDrill);
    el('practiceMistakes').classList.toggle('hidden', mode !== 'mistakes');
    el('btnPracticeNewHand').classList.toggle('hidden', mode !== 'explore');
    el('practiceModeCaption').textContent = PRACTICE_MODE_CAPTIONS[mode] || '';
    // Mode switching is locked while a retry is in flight — but it has to be unlocked
    // again the moment the retry ends, and the retry ends by landing on the Mistakes pane,
    // which never re-renders the drill. So own the enabled state here rather than leaving
    // it to whichever pane happened to render last.
    const retrying = !!(rapid && rapid.retry);
    document.querySelectorAll('#practiceModeRow .rapid-mode-btn').forEach((b) => {
      const m = b.dataset.practiceMode;
      b.classList.toggle('active', m === mode);
      if (m !== 'mistakes' && m !== 'explore') b.disabled = retrying;
    });

    if (isDrill) {
      ensureRapidState();
      if (rapid.mode !== mode) {
        // switching between drills starts a fresh hand for the new one
        rapid.mode = mode;
        rapid.current = null;
        rapid.next = null;
        el('rapidFeedback').classList.add('hidden');
        renderRapidStats();
        renderRapidDrill();
        rapidNext();
      } else {
        renderRapidStats();
        renderRapidDrill();
        if (!rapid.current && !rapid.loading) rapidNext();
      }
    } else if (mode === 'mistakes') {
      ensureRapidState();
      setRapidView('mistakes');
    } else if (!practice) {
      startPractice();
    }
  }

  // ---------- hand difficulty filter ----------
  // Every pool entry carries `ev`: what the solver's own split for that hand is worth
  // against the field, measured over 300 boards offline (see experiments/solve/
  // measure_pool_ev.js). That makes "only deal me hands GTO can't win with" a lookup
  // rather than something we'd have to solve for at deal time.
  let handFilter = { kind: 'any', min: -Infinity, max: Infinity };

  function poolHasEvData(pool) {
    return !!(pool && pool.length && typeof pool[0].ev === 'number');
  }

  // Percentile cut points, computed once from the pool itself rather than hardcoded, so the
  // presets stay honest if the pool is ever regenerated.
  let evQuantiles = null;
  function ensureEvQuantiles(pool) {
    if (evQuantiles || !poolHasEvData(pool)) return evQuantiles;
    const sorted = pool.map((e) => e.ev).sort((a, b) => a - b);
    const at = (q) => sorted[Math.min(sorted.length - 1, Math.max(0, Math.round(q * (sorted.length - 1))))];
    evQuantiles = { p20: at(0.2), p30: at(0.3), p70: at(0.7), p80: at(0.8) };
    return evQuantiles;
  }

  function handFilterRange(pool) {
    const q = ensureEvQuantiles(pool);
    switch (handFilter.kind) {
      case 'rough': return q ? { min: -Infinity, max: q.p20 } : null;
      case 'belowzero': return { min: -Infinity, max: 0 };
      case 'average': return q ? { min: q.p30, max: q.p70 } : null;
      case 'premium': return q ? { min: q.p80, max: Infinity } : null;
      case 'custom': return { min: handFilter.min, max: handFilter.max };
      default: return null;
    }
  }

  function filteredPool(pool) {
    const range = handFilterRange(pool);
    if (!range || !poolHasEvData(pool)) return pool;
    const out = pool.filter((e) => e.ev >= range.min && e.ev <= range.max);
    // Never hand back an empty deck: a range nothing matches falls back to the full pool
    // and the UI says so, rather than silently failing to deal.
    return out.length >= 20 ? out : pool;
  }

  function renderHandFilterCount() {
    const node = el('handFilterCount');
    if (!opponentPool) { node.textContent = ''; return; }
    if (!poolHasEvData(opponentPool)) {
      node.textContent = 'this pool has no solved EVs, so filtering is unavailable';
      return;
    }
    const range = handFilterRange(opponentPool);
    if (!range) { node.textContent = `${opponentPool.length.toLocaleString()} hands available`; return; }
    const matching = opponentPool.filter((e) => e.ev >= range.min && e.ev <= range.max).length;
    const pct = ((matching / opponentPool.length) * 100).toFixed(0);
    node.textContent = matching >= 20
      ? `${matching.toLocaleString()} hands match (${pct}% of the pool)`
      : `only ${matching} hands match — too few, dealing from the full pool instead`;
  }

  function applyHandFilterUi() {
    const kind = el('handFilterSelect').value;
    handFilter.kind = kind;
    el('handFilterCustom').classList.toggle('hidden', kind !== 'custom');
    const min = parseFloat(el('handFilterMin').value);
    const max = parseFloat(el('handFilterMax').value);
    handFilter.min = isNaN(min) ? -Infinity : min;
    handFilter.max = isNaN(max) ? Infinity : max;
    renderHandFilterCount();
  }

  // ---------- rapid fire (GTO drills) ----------
  // Three drills on the one decision this game actually has, all scored against the same
  // homerun-solved opponents Practice Mode uses (full-match-sweep bonus included, since
  // that's always on):
  //   arrange  — you build the 1/2/4 split yourself, graded against the true best of all
  //              105 partitions of that hand.
  //   estimate — you build the split AND price it: one EV guess per hand (1-card, 2-card,
  //              4-card PLO), so you practise reading where the points actually come from
  //              rather than just recognizing good shapes.
  //   locked   — the 2-card NLH hand is fixed for you; you choose which of the remaining
  //              five cards plays alone, and the other four become the PLO hand.
  // Quiz hands are drawn from the solved pool itself, so the offline solver's own split for
  // the hand is always reachable — but "best" is always whatever genuinely graded best on
  // this hand's board set, never an assumption about what the solver picked.
  //
  // The "show live EV" assist (rapid.assist) is a training wheel: it prices each hand as
  // you build it. Hands played with it on are deliberately NOT scored — the whole point of
  // the averages is that they measure unaided judgement.
  // Every mode uses the same board count as free play, so a split's EV reads the same
  // wherever you see it. 120 used to be a speed compromise; the table-based solver below
  // made it unnecessary — 500 boards now grade faster than 120 did before.
  const RAPID_TRIALS = 500;
  const RAPID_LOCKED_TRIALS = 500;
  const RAPID_EST_TRIALS = 500;
  // "Close EV is fine": within this of the best split counts as correct. Two splits inside
  // ~0.15 pts/hand are a coin flip at this many boards (well inside the standard error), so
  // insisting on the exact argmax would be grading Monte Carlo noise.
  const RAPID_TOLERANCE = 0.15;
  const RAPID_TIERS = [
    { key: 'inaccuracy', label: 'Inaccuracy', mark: '?!', max: 0.75 },
    { key: 'mistake', label: 'Mistake', mark: '?', max: 2.0 },
    { key: 'blunder', label: 'Blunder', mark: '??', max: Infinity }
  ];
  // Estimate mode grades absolute error instead of EV lost, so it needs its own scale.
  const RAPID_EST_TOLERANCE = 0.75;
  const RAPID_EST_TIERS = [
    { key: 'inaccuracy', label: 'Close', mark: '?!', max: 2.0 },
    { key: 'mistake', label: 'Off', mark: '?', max: 4.0 },
    { key: 'blunder', label: 'Way off', mark: '??', max: Infinity }
  ];
  const RAPID_CATS = ['one', 'two', 'four'];
  const RAPID_MODE_HINTS = {
    arrange: 'Build the highest-EV split you can. Click a card then a hand, press 1-7 to drop the next card into the first open slot, Backspace to undo. Graded against all 105 ways to split this hand.',
    estimate: 'Build a split, then price each hand: what is the 1-card hand worth per hand played, and the 2-card, and the PLO hand? Negative is normal — most hands lose ground somewhere against a solved opponent.',
    locked: 'The 2-card NLH hand is locked. Pick which of the five remaining cards plays as the 1-card hand — the other four become the PLO hand. Press 1-5 or click.'
  };

  let rapid = null;

  function rapidNewModeStats() {
    return { played: 0, totalLoss: 0, totalAbsErr: 0, totalSignedErr: 0, totalPerHandErr: 0,
      streak: 0, bestStreak: 0, counts: { best: 0, inaccuracy: 0, mistake: 0, blunder: 0 } };
  }

  function rapidNewState() {
    return {
      mode: 'arrange',
      assist: false,
      current: null,
      next: null,
      stats: { arrange: rapidNewModeStats(), estimate: rapidNewModeStats(), locked: rapidNewModeStats() },
      mistakes: [],
      mistakeSeq: 0,
      view: 'drill',
      retry: null,
      loading: false
    };
  }

  function nextTick() { return new Promise((resolve) => setTimeout(resolve, 0)); }

  // Score an arbitrary list of partitions against a fixed trial set, returning every one
  // ranked. Same shape of optimization as Practice Mode's ideal-split search — the
  // opponent's evaluation is hoisted out of the partition loop, and the expensive 4-card
  // PLO evaluation is computed once per distinct 4-card subset rather than once per
  // partition — but it keeps ALL results instead of just the winner, which is what lets a
  // freely-arranged split be ranked (#k of 105) rather than only compared to the best.
  // Runs in small batches with a yield between them so the tab never freezes.
  // Score a list of partitions of the SAME seven cards against a fixed trial set, ranked.
  //
  // Across the 105 partitions of one hand there are only 7 distinct 1-card hands, 21
  // distinct 2-card hands and 21 distinct hole PAIRS — and a PLO hand is by definition
  // exactly 2 hole cards plus 3 board cards, so the best PLO hand for a 4-card group is
  // just the best of its 6 pairs. So per board we evaluate three small tables once and
  // every hand any partition could hold becomes a max over a couple of lookups:
  //   1-card {c}        = max(boardOnly, single[c])
  //   2-card {a,b}      = max(boardOnly, single[a], single[b], pair[a,b])
  //   4-card PLO {abcd} = max over its 6 pairs
  // That's 246 evaluations per board instead of ~5,000. Same approach (and same answers)
  // as lib/bot.js uses for live bot seats.
  function scorePartitionsAsync(parts, trials, onProgress) {
    return new Promise((resolve) => {
      const Poker = window.Poker;
      const hand = [...parts[0].one, ...parts[0].two, ...parts[0].four];
      const pos = new Map(hand.map((c, i) => [c, i]));

      const PAIRS = [];
      const pairAt = [];
      for (let a = 0; a < 7; a++) for (let b = a + 1; b < 7; b++) { pairAt[a * 7 + b] = pairAt[b * 7 + a] = PAIRS.length; PAIRS.push([a, b]); }
      const B4 = [];
      for (let drop = 0; drop < 5; drop++) B4.push([0, 1, 2, 3, 4].filter((x) => x !== drop));
      const B3 = [];
      for (let x = 0; x < 5; x++) for (let y = x + 1; y < 5; y++) for (let z = y + 1; z < 5; z++) B3.push([x, y, z]);

      // each partition as index tuples into the tables
      const specs = parts.map((p) => {
        const two = p.two.map((c) => pos.get(c));
        const four = p.four.map((c) => pos.get(c));
        const quadPairs = [];
        for (let a = 0; a < 4; a++) for (let b = a + 1; b < 4; b++) quadPairs.push(pairAt[four[a] * 7 + four[b]]);
        return { one: pos.get(p.one[0]), pair: pairAt[two[0] * 7 + two[1]], two, quadPairs };
      });

      const totals = new Float64Array(parts.length);
      const single = new Array(7);
      const pair = new Array(PAIRS.length);
      const d1 = [new Int8Array(7), new Int8Array(7)];
      const d2 = [new Int8Array(PAIRS.length), new Int8Array(PAIRS.length)];
      const best = (a, b) => (a === null ? b : b === null ? a : (Poker.compareScores(a, b) >= 0 ? a : b));
      let ti = 0;

      function scoreTrialFast(trial) {
        const boards = [trial.boardA, trial.boardB];
        for (let b = 0; b < 2; b++) {
          const board = boards[b];
          const boardOnly = Poker.evaluate5(board);
          for (let c = 0; c < 7; c++) {
            let v = null;
            for (let k = 0; k < B4.length; k++) {
              const sub = B4[k];
              v = best(v, Poker.evaluate5([hand[c], board[sub[0]], board[sub[1]], board[sub[2]], board[sub[3]]]));
            }
            single[c] = v;
          }
          for (let k = 0; k < PAIRS.length; k++) {
            const i = PAIRS[k][0];
            const j = PAIRS[k][1];
            let v = null;
            for (let t = 0; t < B3.length; t++) {
              const sub = B3[t];
              v = best(v, Poker.evaluate5([hand[i], hand[j], board[sub[0]], board[sub[1]], board[sub[2]]]));
            }
            pair[k] = v;
          }
          const oppOne = evalHandOnBoard(trial.oppSplit.one, board, 'one').score;
          const oppTwo = evalHandOnBoard(trial.oppSplit.two, board, 'two').score;
          const oppFour = evalHandOnBoard(trial.oppSplit.four, board, 'four').score;
          for (let c = 0; c < 7; c++) {
            const cmp = Poker.compareScores(best(boardOnly, single[c]), oppOne);
            d1[b][c] = cmp > 0 ? 1 : cmp < 0 ? -1 : 0;
          }
          for (let k = 0; k < PAIRS.length; k++) {
            const i = PAIRS[k][0];
            const j = PAIRS[k][1];
            const cmp = Poker.compareScores(best(best(boardOnly, best(single[i], single[j])), pair[k]), oppTwo);
            d2[b][k] = cmp > 0 ? 2 : cmp < 0 ? -2 : 0;
          }
          for (let sIdx = 0; sIdx < specs.length; sIdx++) {
            const qp = specs[sIdx].quadPairs;
            let v = pair[qp[0]];
            for (let x = 1; x < qp.length; x++) v = best(v, pair[qp[x]]);
            const cmp = Poker.compareScores(v, oppFour);
            specs[sIdx]['d4' + b] = cmp > 0 ? 3 : cmp < 0 ? -3 : 0;
          }
        }
        for (let sIdx = 0; sIdx < specs.length; sIdx++) {
          const sp = specs[sIdx];
          const a1 = d1[0][sp.one];
          const b1 = d1[1][sp.one];
          const a2 = d2[0][sp.pair];
          const b2 = d2[1][sp.pair];
          const a4 = sp.d40;
          const b4 = sp.d41;
          let pts = a1 + b1 + a2 + b2 + a4 + b4;
          if (a1 > 0 && b1 > 0 && a2 > 0 && b2 > 0 && a4 > 0 && b4 > 0) pts += PRACTICE_MATCH_TOTAL;
          else if (a1 < 0 && b1 < 0 && a2 < 0 && b2 < 0 && a4 < 0 && b4 < 0) pts -= PRACTICE_MATCH_TOTAL;
          totals[sIdx] += pts;
        }
      }

      function step() {
        // time-sliced so a long search never freezes the tab
        const started = Date.now();
        do { scoreTrialFast(trials[ti++]); } while (ti < trials.length && Date.now() - started < 8);
        if (onProgress) onProgress(ti / trials.length);
        if (ti < trials.length) { setTimeout(step, 0); return; }
        const scored = parts.map((assignment, idx) => ({
          assignment,
          key: fmtAssignmentKey(assignment),
          ev: totals[idx] / trials.length
        }));
        scored.sort((a, b) => b.ev - a.ev);
        resolve(scored);
      }
      step();
    });
  }

  // The opponent's evaluations don't depend on how YOU split, so cache them once per hand.
  // That's what makes pricing a single hand-group cheap enough to redo on every card
  // placement for the live-EV assist.
  function ensureOppCache(quiz) {
    if (!quiz.oppCache) {
      quiz.oppCache = quiz.trials.map((t) => ({
        one: [evalHandOnBoard(t.oppSplit.one, t.boardA, 'one').score, evalHandOnBoard(t.oppSplit.one, t.boardB, 'one').score],
        two: [evalHandOnBoard(t.oppSplit.two, t.boardA, 'two').score, evalHandOnBoard(t.oppSplit.two, t.boardB, 'two').score],
        four: [evalHandOnBoard(t.oppSplit.four, t.boardA, 'four').score, evalHandOnBoard(t.oppSplit.four, t.boardB, 'four').score]
      }));
    }
    return quiz.oppCache;
  }

  // Average points this one hand-group wins or loses per hand played, across both boards.
  // Each category is compared only against the opponent's same category, so a group can be
  // priced on its own without the rest of the split being decided.
  function categoryEv(cards, cat, quiz) {
    const cache = ensureOppCache(quiz);
    const pts = PRACTICE_POINTS[cat];
    let total = 0;
    for (let i = 0; i < quiz.trials.length; i++) {
      const t = quiz.trials[i];
      const boards = [t.boardA, t.boardB];
      for (let b = 0; b < 2; b++) {
        const cmp = window.Poker.compareScores(evalHandOnBoard(cards, boards[b], cat).score, cache[i][cat][b]);
        total += cmp > 0 ? pts : cmp < 0 ? -pts : 0;
      }
    }
    return total / quiz.trials.length;
  }

  // Per-hand EV of a complete split, plus the homerun bonus broken out. The bonus can't be
  // attributed to any single hand-group (it only exists when all six comparisons sweep), so
  // it's reported on its own line rather than smeared across the three.
  function splitEvBreakdown(result) {
    const cats = {};
    let subtotal = 0;
    RAPID_CATS.forEach((cat) => {
      cats[cat] = result.avgCells[cat][0] + result.avgCells[cat][1];
      subtotal += cats[cat];
    });
    return { cats, subtotal, homerun: result.avgTotal - subtotal, total: result.avgTotal };
  }

  function rapidSeedHand(pool) {
    const usable = filteredPool(pool);
    const seed = usable[Math.floor(Math.random() * usable.length)];
    return { seed, hand: [...seed.one, ...seed.two, ...seed.four] };
  }

  function emptyArrangeFields() {
    return { assignment: { one: [], two: [], four: [] }, selected: null, placeOrder: [] };
  }

  async function buildArrangeQuiz() {
    const pool = await loadOpponentPool();
    const { hand } = rapidSeedHand(pool);
    const trials = buildPracticeTrials(hand, pool, RAPID_TRIALS);
    const quiz = Object.assign({ mode: 'arrange', hand, trials, solved: null, answered: false }, emptyArrangeFields());
    // Solve in the background while the player arranges — by the time anyone has placed
    // seven cards, the full 105-partition answer is already waiting.
    quiz.solvePromise = scorePartitionsAsync(allPartitions(hand), trials).then((s) => { quiz.solved = s; return s; });
    return quiz;
  }

  // Estimate mode deals a hand and nothing else: you choose the split AND price it, so
  // there's no solve to precompute — the target is whatever your own split turns out to be
  // worth, which is only known once you've built it.
  async function buildEstimateQuiz() {
    const pool = await loadOpponentPool();
    const { hand } = rapidSeedHand(pool);
    const trials = buildPracticeTrials(hand, pool, RAPID_EST_TRIALS);
    return Object.assign({
      mode: 'estimate', hand, trials, answered: false,
      guesses: { one: null, two: null, four: null }, result: null, breakdown: null
    }, emptyArrangeFields());
  }

  async function buildLockedQuiz() {
    const pool = await loadOpponentPool();
    const { seed, hand } = rapidSeedHand(pool);
    const trials = buildPracticeTrials(hand, pool, RAPID_LOCKED_TRIALS);
    const lockedTwo = [...seed.two]; // the solver's own NLH hand for this holding
    const rest = hand.filter((c) => !lockedTwo.includes(c));
    const parts = rest.map((c) => ({ one: [c], two: lockedTwo, four: rest.filter((x) => x !== c) }));
    const quiz = { mode: 'locked', hand, trials, lockedTwo, rest, parts, solved: null, answered: false, chosenCard: null };
    quiz.solvePromise = scorePartitionsAsync(parts, trials).then((s) => { quiz.solved = s; return s; });
    return quiz;
  }

  function buildQuizForMode(mode) {
    if (mode === 'estimate') return buildEstimateQuiz();
    if (mode === 'locked') return buildLockedQuiz();
    return buildArrangeQuiz();
  }

  function classifyLoss(loss, mode) {
    const tiers = mode === 'estimate' ? RAPID_EST_TIERS : RAPID_TIERS;
    const tol = mode === 'estimate' ? RAPID_EST_TOLERANCE : RAPID_TOLERANCE;
    if (loss <= tol) return { key: 'best', label: mode === 'estimate' ? 'Sharp' : 'Best', mark: '!' };
    return tiers.find((t) => loss <= t.max);
  }

  // A short rising two-note blip — deliberately much shorter than the live game's win
  // chime, since in a drill you hear it many times a minute.
  function playCorrectSound() {
    if (!soundEnabled) return;
    const ctx = getAudioCtx();
    if (!ctx) return;
    const now = ctx.currentTime;
    playTone(ctx, 880, now, 0.1, 0.14); // A5
    playTone(ctx, 1318.51, now + 0.075, 0.14, 0.13); // E6
  }

  function rapidActiveQuiz() {
    return rapid && (rapid.retry ? rapid.retry.quiz : rapid.current);
  }
  function rapidModeStats() { return rapid.stats[rapid.mode]; }
  function rapidUsesArranger(quiz) { return quiz && (quiz.mode === 'arrange' || quiz.mode === 'estimate'); }

  function splitGroupsNode(assignment, opts = {}) {
    const wrap = document.createElement('div');
    wrap.className = 'rapid-split-groups';
    const labels = { one: '1', two: '2', four: '4' };
    RAPID_CATS.forEach((cat) => {
      const group = document.createElement('span');
      group.className = 'rapid-split-group';
      const lbl = document.createElement('span');
      lbl.className = 'hc-label';
      lbl.textContent = labels[cat] + ':';
      group.appendChild(lbl);
      group.appendChild(cardRow(assignment[cat], { size: opts.size || 'small' }));
      wrap.appendChild(group);
    });
    return wrap;
  }

  function renderRapidStats() {
    const st = rapidModeStats();
    const isEst = rapid.mode === 'estimate';
    const headlineVal = st.played ? (isEst ? st.totalAbsErr : st.totalLoss) / st.played : 0;
    const headlineLabel = isEst ? 'Avg total EV error' : 'Avg EV lost / hand';
    const good = isEst ? 1.0 : 0.25;
    const mid = isEst ? 2.5 : 0.9;
    const bias = st.played ? st.totalSignedErr / st.played : 0;
    const perHand = st.played ? st.totalPerHandErr / st.played : 0;
    const extra = isEst
      ? `<div class="rapid-stat">
           <span class="rs-label">Per-hand err</span>
           <span class="rs-value">${st.played ? perHand.toFixed(2) : '—'}</span>
         </div>
         <div class="rapid-stat">
           <span class="rs-label">Bias</span>
           <span class="rs-value">${st.played ? `${bias > 0 ? '+' : ''}${bias.toFixed(2)} <span class="rs-sub">${Math.abs(bias) < 0.3 ? '(calibrated)' : bias > 0 ? '(too high)' : '(too low)'}</span>` : '—'}</span>
         </div>`
      : `<div class="rapid-stat">
           <span class="rs-label">Streak</span>
           <span class="rs-value">${st.streak}${st.bestStreak ? ` <span class="rs-sub">(best ${st.bestStreak})</span>` : ''}</span>
         </div>`;
    el('rapidStats').innerHTML = `
      <div class="rapid-stat headline">
        <span class="rs-label">${headlineLabel}</span>
        <span class="rs-value ${headlineVal <= good ? 'good' : headlineVal <= mid ? 'mid' : 'bad'}">${headlineVal.toFixed(3)}</span>
      </div>
      <div class="rapid-stat">
        <span class="rs-label">Hands</span>
        <span class="rs-value">${st.played}</span>
      </div>
      <div class="rapid-stat">
        <span class="rs-label">${isEst ? 'Sharp' : 'Best found'}</span>
        <span class="rs-value">${st.counts.best}${st.played ? ` <span class="rs-sub">(${((st.counts.best / st.played) * 100).toFixed(0)}%)</span>` : ''}</span>
      </div>
      ${extra}
      <div class="rapid-stat tiers">
        <span class="tier-chip inaccuracy">${isEst ? 'Close' : '?!'} ${st.counts.inaccuracy}</span>
        <span class="tier-chip mistake">${isEst ? 'Off' : '?'} ${st.counts.mistake}</span>
        <span class="tier-chip blunder">${isEst ? 'Way off' : '??'} ${st.counts.blunder}</span>
      </div>`;
    el('rapidMistakeCount').textContent = rapid.mistakes.filter((m) => !m.resolved).length;
  }

  // ---- the arranger (shared by arrange + estimate) ----
  function rapidTrayCards(quiz) {
    const used = new Set([...quiz.assignment.one, ...quiz.assignment.two, ...quiz.assignment.four]);
    return sortCards(quiz.hand.filter((c) => !used.has(c)), cardSortMode);
  }

  function rapidPlace(quiz, card, slot) {
    if (quiz.assignment[slot].length >= CAPACITY[slot]) return false;
    quiz.assignment[slot].push(card);
    quiz.placeOrder.push({ slot, card });
    return true;
  }

  function rapidUnplace(quiz, card) {
    for (const slot of RAPID_CATS) {
      if (quiz.assignment[slot].includes(card)) {
        quiz.assignment[slot] = quiz.assignment[slot].filter((c) => c !== card);
        quiz.placeOrder = quiz.placeOrder.filter((p) => p.card !== card);
        return;
      }
    }
  }

  function rapidPlaceFirstOpen(quiz, card) {
    for (const slot of RAPID_CATS) {
      if (quiz.assignment[slot].length < CAPACITY[slot]) { rapidPlace(quiz, card, slot); return true; }
    }
    return false;
  }

  function rapidArrangeComplete(quiz) {
    return quiz.assignment.one.length === 1 && quiz.assignment.two.length === 2 && quiz.assignment.four.length === 4;
  }

  function renderRapidArrange() {
    const quiz = rapidActiveQuiz();
    RAPID_CATS.forEach((slot) => {
      const container = el('rSlot' + capitalize(slot));
      container.innerHTML = '';
      quiz.assignment[slot].forEach((c) => {
        const node = cardEl(c);
        if (!quiz.answered) {
          node.addEventListener('click', (ev) => {
            ev.stopPropagation();
            rapidUnplace(quiz, c);
            quiz.selected = null;
            renderRapidDrill();
          });
        }
        container.appendChild(node);
      });
    });

    const tray = el('rTray');
    tray.innerHTML = '';
    if (quiz.answered) {
      const msg = document.createElement('div');
      msg.className = 'hint';
      msg.textContent = 'Graded — see below.';
      tray.appendChild(msg);
    } else {
      rapidTrayCards(quiz).forEach((c, i) => {
        const node = cardEl(c);
        if (quiz.selected === c) node.classList.add('selected');
        const num = document.createElement('span');
        num.className = 'rapid-tray-key';
        num.textContent = String(i + 1);
        node.appendChild(num);
        node.addEventListener('click', (ev) => {
          if (ev.metaKey || ev.ctrlKey) {
            rapidPlaceFirstOpen(quiz, c);
            quiz.selected = null;
          } else {
            quiz.selected = quiz.selected === c ? null : c;
          }
          renderRapidDrill();
        });
        tray.appendChild(node);
      });
    }

    document.querySelectorAll('#rapidSlots .slot').forEach((slotDiv) => {
      slotDiv.onclick = () => {
        if (quiz.answered || !quiz.selected) return;
        if (rapidPlace(quiz, quiz.selected, slotDiv.dataset.rslot)) quiz.selected = null;
        renderRapidDrill();
      };
    });

    el('btnRapidSubmit').disabled = quiz.answered || !rapidArrangeComplete(quiz);
    el('btnRapidClear').disabled = quiz.answered;
  }

  // ---- live EV assist ----
  // Prices each hand-group that's currently complete. Incomplete groups show a dash rather
  // than a misleading partial number. Once all three are placed it switches to the full
  // evaluation, which is also the only point at which the homerun bonus can exist.
  function renderRapidLiveEv() {
    const quiz = rapidActiveQuiz();
    const panel = el('rapidLiveEv');
    if (!rapid.assist || !rapidUsesArranger(quiz) || quiz.answered) {
      panel.classList.add('hidden');
      return;
    }
    const complete = rapidArrangeComplete(quiz);
    let cats = {};
    let homerun = null;
    let total = null;
    if (complete) {
      const b = splitEvBreakdown(evalAssignmentAcrossTrials(quiz.assignment, quiz.trials, practiceHomerunMode));
      cats = b.cats; homerun = b.homerun; total = b.total;
    } else {
      RAPID_CATS.forEach((cat) => {
        cats[cat] = quiz.assignment[cat].length === CAPACITY[cat] ? categoryEv(quiz.assignment[cat], cat, quiz) : null;
      });
    }
    const cell = (v) => v === null
      ? '<span class="rle-val none">—</span>'
      : `<span class="rle-val ${v > 0 ? 'pos' : v < 0 ? 'neg' : 'even'}">${fmtEv(v)}</span>`;
    panel.innerHTML = `
      <span class="rle-title">Live EV</span>
      <span class="rle-item"><span class="rle-label">1-card</span>${cell(cats.one)}</span>
      <span class="rle-item"><span class="rle-label">2-card</span>${cell(cats.two)}</span>
      <span class="rle-item"><span class="rle-label">4-card PLO</span>${cell(cats.four)}</span>
      <span class="rle-item"><span class="rle-label">Homerun</span>${cell(homerun)}</span>
      <span class="rle-item total"><span class="rle-label">Total</span>${cell(total)}</span>
      <span class="rle-note">${complete ? 'assisted — this hand is not scored' : 'each hand prices itself once it is full'}</span>`;
    panel.classList.remove('hidden');
  }

  // ---- estimate mode ----
  function renderRapidEstimate() {
    const quiz = rapidActiveQuiz();
    const complete = rapidArrangeComplete(quiz);
    el('rapidEstGate').classList.toggle('hidden', complete);
    el('rapidEstFields').classList.toggle('hidden', !complete);

    RAPID_CATS.forEach((cat) => {
      const input = el('rapidEst' + capitalize(cat));
      input.disabled = quiz.answered || !complete;
      if (!quiz.answered && !complete) input.value = '';
    });
    el('btnRapidEstSubmit').disabled = quiz.answered || !complete;
    renderRapidEstTotal();
    if (!quiz.answered) el('rapidEstReveal').classList.add('hidden');
  }

  function rapidEstGuesses() {
    const out = {};
    RAPID_CATS.forEach((cat) => {
      const raw = el('rapidEst' + capitalize(cat)).value.trim();
      out[cat] = raw === '' || isNaN(Number(raw)) ? null : Number(raw);
    });
    return out;
  }

  function renderRapidEstTotal() {
    const g = rapidEstGuesses();
    const filled = RAPID_CATS.filter((c) => g[c] !== null);
    el('rapidEstTotal').textContent = filled.length === 3
      ? fmtEv(g.one + g.two + g.four)
      : `— (${filled.length}/3 priced)`;
  }

  function renderRapidEstimateReveal() {
    const quiz = rapidActiveQuiz();
    const b = quiz.breakdown;
    const labels = { one: '1-Card Hand', two: '2-Card Hand', four: '4-Card PLO Hand' };
    const rows = RAPID_CATS.map((cat) => {
      const err = quiz.guesses[cat] - b.cats[cat];
      return `<div class="rer-row">
        <span class="rer-label">${labels[cat]}</span>
        <span class="rer-guess">you said ${fmtEv(quiz.guesses[cat])}</span>
        <span class="rer-actual ${b.cats[cat] > 0 ? 'pos' : b.cats[cat] < 0 ? 'neg' : 'even'}">actually ${fmtEv(b.cats[cat])}</span>
        <span class="rer-err ${Math.abs(err) <= RAPID_EST_TOLERANCE ? 'ok' : ''}">${err > 0 ? 'over' : 'under'} by ${Math.abs(err).toFixed(2)}</span>
      </div>`;
    }).join('');
    const guessTotal = quiz.guesses.one + quiz.guesses.two + quiz.guesses.four;
    el('rapidEstReveal').innerHTML = `
      <div class="rer-rows">${rows}</div>
      <div class="rer-summary">
        <span>Your three hands: <strong>${fmtEv(guessTotal)}</strong> vs. actual <strong class="${b.subtotal > 0 ? 'pos' : 'neg'}">${fmtEv(b.subtotal)}</strong></span>
        <span class="rer-hr">⚾ Homerun bonus (can't be attributed to one hand): <strong>${fmtEv(b.homerun)}</strong></span>
        <span>Whole split is worth <strong class="${b.total > 0 ? 'pos' : 'neg'}">${fmtEv(b.total)}</strong> pts/hand</span>
      </div>`;
    el('rapidEstReveal').classList.remove('hidden');
  }

  // ---- locked-NLH mode ----
  function renderRapidLocked() {
    const quiz = rapidActiveQuiz();
    const lockedWrap = el('rapidLockedTwo');
    lockedWrap.innerHTML = '';
    const lbl = document.createElement('span');
    lbl.className = 'hc-label';
    lbl.textContent = 'Locked 2-card NLH hand:';
    lockedWrap.appendChild(lbl);
    lockedWrap.appendChild(cardRow(quiz.lockedTwo));

    // With the assist on, every completion is priced up front — that's the whole point of
    // the training wheel, and it's why assisted hands aren't scored.
    const reveal = quiz.answered || (rapid.assist && quiz.solved);
    const choices = el('rapidLockedChoices');
    choices.innerHTML = '';
    sortCards(quiz.rest, cardSortMode).forEach((card, i) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'rapid-locked-choice';
      btn.disabled = quiz.answered;

      const num = document.createElement('span');
      num.className = 'rapid-opt-num';
      num.textContent = String(i + 1);
      btn.appendChild(num);

      [['1:', [card]], ['4:', quiz.rest.filter((x) => x !== card)]].forEach(([text, cards]) => {
        const part = document.createElement('span');
        part.className = 'rlc-part';
        const l = document.createElement('span');
        l.className = 'hc-label';
        l.textContent = text;
        part.appendChild(l);
        part.appendChild(cardRow(cards, { size: 'small' }));
        btn.appendChild(part);
      });

      const meta = document.createElement('span');
      meta.className = 'rapid-opt-meta';
      if (reveal) {
        const entry = quiz.solved.find((s) => s.assignment.one[0] === card);
        const loss = quiz.solved[0].ev - entry.ev;
        const ev = document.createElement('span');
        ev.className = 'rapid-opt-ev';
        ev.textContent = `${fmtEv(entry.ev)} EV`;
        meta.appendChild(ev);
        if (loss > RAPID_TOLERANCE) {
          const l = document.createElement('span');
          l.className = 'rapid-opt-loss';
          l.textContent = `−${loss.toFixed(2)}`;
          meta.appendChild(l);
        }
        if (entry.key === quiz.solved[0].key) btn.classList.add('is-best');
        else if (loss <= RAPID_TOLERANCE) btn.classList.add('is-close');
        if (quiz.answered && card === quiz.chosenCard) btn.classList.add('is-chosen');
      }
      btn.appendChild(meta);

      if (!quiz.answered) btn.addEventListener('click', () => rapidAnswerLocked(card));
      choices.appendChild(btn);
    });
  }

  // ---- shared rendering ----
  function renderRapidDrill() {
    const quiz = rapidActiveQuiz();
    const isRetry = !!(rapid && rapid.retry);

    el('rapidRetryBanner').classList.toggle('hidden', !isRetry);
    if (isRetry) {
      const m = rapid.retry.mistake;
      el('rapidRetryBanner').innerHTML = `↻ Retrying a stored ${m.tier.label.toLowerCase()} — same hand, same boards. Retries don't count toward your session average.`;
    }

    document.querySelectorAll('#practiceModeRow .rapid-mode-btn').forEach((b) => {
      const m = b.dataset.practiceMode;
      if (m && m !== 'mistakes' && m !== 'explore') b.disabled = isRetry;
    });
    el('rapidModeHint').textContent = RAPID_MODE_HINTS[rapid.mode];
    el('rapidAssist').checked = rapid.assist;

    ['rapidArrange', 'rapidArrangeActions', 'rapidEstimate', 'rapidLocked', 'rapidLiveEv'].forEach((id) => el(id).classList.add('hidden'));
    if (!quiz) {
      el('rapidLoading').classList.remove('hidden');
      el('btnRapidNext').classList.add('hidden');
      return;
    }
    el('rapidLoading').classList.add('hidden');

    if (rapidUsesArranger(quiz)) {
      el('rapidArrange').classList.remove('hidden');
      renderRapidArrange();
      renderRapidLiveEv();
      if (quiz.mode === 'arrange') el('rapidArrangeActions').classList.remove('hidden');
      else { el('rapidEstimate').classList.remove('hidden'); renderRapidEstimate(); if (quiz.answered) renderRapidEstimateReveal(); }
    } else {
      el('rapidLocked').classList.remove('hidden');
      renderRapidLocked();
    }

    el('btnRapidNext').classList.toggle('hidden', !quiz.answered);
    el('btnRapidNext').textContent = isRetry ? 'Back to Mistakes' : 'Next Hand (Enter)';
  }

  // Records a graded hand. `assisted` hands are deliberately left out of the averages --
  // the stats are meant to measure unaided judgement, and the live-EV panel hands you the
  // answer. They still get graded and shown, they just don't move the numbers.
  function rapidRecord(tier, loss, signedErr, perHandErr, quiz, extra) {
    const isRetry = !!rapid.retry;
    const correct = tier.key === 'best';
    const assisted = !!quiz.assisted;
    if (isRetry) {
      const m = rapid.retry.mistake;
      m.attempts = (m.attempts || 0) + 1;
      if (correct) m.resolved = true;
    } else if (!assisted) {
      const st = rapidModeStats();
      st.played++;
      st.totalLoss += loss;
      st.totalAbsErr += Math.abs(signedErr === null ? loss : signedErr);
      if (signedErr !== null) st.totalSignedErr += signedErr;
      if (perHandErr !== null) st.totalPerHandErr += perHandErr;
      st.counts[tier.key]++;
      if (correct) {
        st.streak++;
        if (st.streak > st.bestStreak) st.bestStreak = st.streak;
      } else {
        st.streak = 0;
        // Estimate mode is deliberately not retryable: once you've been told the answer,
        // re-guessing the same hand tests memory, not calibration.
        if (quiz.mode !== 'estimate') {
          rapid.mistakeSeq++;
          rapid.mistakes.push(Object.assign({
            id: rapid.mistakeSeq, mode: quiz.mode, hand: quiz.hand, trials: quiz.trials,
            solved: quiz.solved, loss, tier, attempts: 0, resolved: false
          }, extra));
        }
      }
    }
    if (correct) playCorrectSound();
    return { correct, assisted };
  }

  function rapidAssistNote(assisted) {
    return assisted ? ' <span class="fb-assist">· assisted, not scored</span>' : '';
  }

  async function rapidSubmitArrange() {
    const quiz = rapidActiveQuiz();
    if (!quiz || quiz.answered || !rapidArrangeComplete(quiz)) return;
    if (!quiz.solved) {
      const fb = el('rapidFeedback');
      fb.className = 'rapid-feedback';
      fb.textContent = 'Grading all 105 splits…';
      fb.classList.remove('hidden');
      await quiz.solvePromise;
    }
    quiz.answered = true;
    const key = fmtAssignmentKey(quiz.assignment);
    const rank = quiz.solved.findIndex((s) => s.key === key);
    const mine = quiz.solved[rank];
    const best = quiz.solved[0];
    const loss = Math.max(0, best.ev - mine.ev);
    const tier = classifyLoss(loss, 'arrange');
    const { correct, assisted } = rapidRecord(tier, loss, null, null, quiz, {
      userAssignment: deepCopy(quiz.assignment), bestAssignment: best.assignment,
      userEv: mine.ev, bestEv: best.ev, rank
    });

    const fb = el('rapidFeedback');
    fb.className = 'rapid-feedback tier-' + tier.key;
    fb.innerHTML = `<strong>${tier.mark} ${correct ? (rapid.retry ? 'Fixed' : 'Best split') : tier.label}</strong>
      <span class="fb-sub">your split graded ${fmtEv(mine.ev)} EV · ranked #${rank + 1} of ${quiz.solved.length}${correct ? '' : ` · the best split was ${fmtEv(best.ev)}, costing you ${loss.toFixed(2)} pts/hand`}${rapidAssistNote(assisted)}</span>`;
    if (!correct) {
      const cmp = document.createElement('div');
      cmp.className = 'rapid-best-reveal';
      const lbl = document.createElement('span');
      lbl.className = 'hc-label';
      lbl.textContent = 'Best split:';
      cmp.appendChild(lbl);
      cmp.appendChild(splitGroupsNode(best.assignment));
      fb.appendChild(cmp);
    }
    fb.classList.remove('hidden');

    renderRapidStats();
    renderRapidDrill();
    renderRapidMistakes();
    if (correct && !rapid.retry) setTimeout(() => { if (rapid && rapid.view === 'drill' && !rapid.retry) rapidNext(); }, 1100);
  }

  async function rapidSubmitEstimate() {
    const quiz = rapidActiveQuiz();
    if (!quiz || quiz.answered || !rapidArrangeComplete(quiz)) return;
    const guesses = rapidEstGuesses();
    const missing = RAPID_CATS.find((c) => guesses[c] === null);
    if (missing) { el('rapidEst' + capitalize(missing)).focus(); return; }

    quiz.answered = true;
    quiz.guesses = guesses;
    quiz.result = evalAssignmentAcrossTrials(quiz.assignment, quiz.trials, practiceHomerunMode);
    quiz.breakdown = splitEvBreakdown(quiz.result);

    // Graded on how well the three estimates price the hand as a whole; the per-hand errors
    // are reported separately, since estimates that are each wrong but cancel out is a
    // different (and more forgivable) problem than being wrong about the total.
    const guessTotal = guesses.one + guesses.two + guesses.four;
    const signedErr = guessTotal - quiz.breakdown.subtotal; // positive = too optimistic
    const absErr = Math.abs(signedErr);
    const perHandErr = RAPID_CATS.reduce((s, c) => s + Math.abs(guesses[c] - quiz.breakdown.cats[c]), 0) / 3;
    const tier = classifyLoss(absErr, 'estimate');
    const { correct, assisted } = rapidRecord(tier, absErr, signedErr, perHandErr, quiz, null);

    const worst = RAPID_CATS.reduce((a, c) =>
      Math.abs(guesses[c] - quiz.breakdown.cats[c]) > Math.abs(guesses[a] - quiz.breakdown.cats[a]) ? c : a, 'one');
    const worstLabel = { one: '1-card', two: '2-card', four: 'PLO' }[worst];
    const fb = el('rapidFeedback');
    fb.className = 'rapid-feedback tier-' + tier.key;
    fb.innerHTML = `<strong>${tier.mark} ${tier.label}</strong>
      <span class="fb-sub">your three hands totalled ${absErr.toFixed(2)} off (${signedErr > 0 ? 'too optimistic' : 'too pessimistic'}) · biggest miss was the ${worstLabel} hand${rapidAssistNote(assisted)}</span>`;
    fb.classList.remove('hidden');

    renderRapidStats();
    renderRapidDrill();
    // Estimate mode never auto-advances, even on a sharp read. Its reveal is the whole
    // point of the drill -- per-hand estimate vs. actual, the homerun bonus broken out, the
    // split's real value -- and that's worth reading rather than having it yanked away
    // after a second. The other drills still advance themselves on a correct answer, where
    // there's nothing to study.
  }

  async function rapidAnswerLocked(card) {
    const quiz = rapidActiveQuiz();
    if (!quiz || quiz.answered) return;
    if (!quiz.solved) await quiz.solvePromise;
    quiz.answered = true;
    quiz.chosenCard = card;
    const mine = quiz.solved.find((s) => s.assignment.one[0] === card);
    const best = quiz.solved[0];
    const rank = quiz.solved.findIndex((s) => s.key === mine.key);
    const loss = Math.max(0, best.ev - mine.ev);
    const tier = classifyLoss(loss, 'locked');
    const { correct, assisted } = rapidRecord(tier, loss, null, null, quiz, {
      userAssignment: mine.assignment, bestAssignment: best.assignment,
      userEv: mine.ev, bestEv: best.ev, rank, lockedTwo: quiz.lockedTwo, rest: quiz.rest, parts: quiz.parts
    });

    const fb = el('rapidFeedback');
    fb.className = 'rapid-feedback tier-' + tier.key;
    fb.innerHTML = `<strong>${tier.mark} ${correct ? (rapid.retry ? 'Fixed' : 'Best completion') : tier.label}</strong>
      <span class="fb-sub">${fmtEv(mine.ev)} EV · ranked #${rank + 1} of ${quiz.solved.length} completions${correct ? '' : ` · best was ${fmtEv(best.ev)}, costing you ${loss.toFixed(2)} pts/hand`}${rapidAssistNote(assisted)}</span>`;
    fb.classList.remove('hidden');

    renderRapidStats();
    renderRapidDrill();
    renderRapidMistakes();
    if (correct && !rapid.retry) setTimeout(() => { if (rapid && rapid.view === 'drill' && !rapid.retry) rapidNext(); }, 1100);
  }

  function rapidSubmit() {
    const quiz = rapidActiveQuiz();
    if (!quiz) return;
    if (quiz.mode === 'arrange') rapidSubmitArrange();
    else if (quiz.mode === 'estimate') rapidSubmitEstimate();
  }

  async function rapidNext() {
    if (!rapid) return;
    if (rapid.retry) {
      rapid.retry = null;
      setPracticeMode('mistakes');
      return;
    }
    el('rapidFeedback').classList.add('hidden');
    if (rapid.next) {
      rapid.current = rapid.next;
      rapid.next = null;
      rapid.current.assisted = rapid.assist;
      renderRapidDrill();
      preloadRapidNext();
      return;
    }
    if (rapid.loading) return;
    rapid.loading = true;
    rapid.current = null;
    renderRapidDrill();
    const mode = rapid.mode;
    const quiz = await buildQuizForMode(mode);
    rapid.loading = false;
    if (!rapid || rapid.mode !== mode) return; // mode switched while building
    quiz.assisted = rapid.assist;
    rapid.current = quiz;
    renderRapidDrill();
    preloadRapidNext();
  }

  async function preloadRapidNext() {
    if (!rapid || rapid.next || rapid.loading) return;
    const mode = rapid.mode;
    const quiz = await buildQuizForMode(mode);
    if (rapid && rapid.mode === mode && !rapid.next) rapid.next = quiz;
  }

  async function setRapidMode(mode) {
    if (!rapid || rapid.mode === mode || rapid.retry) return;
    rapid.mode = mode;
    rapid.current = null;
    rapid.next = null;
    el('rapidFeedback').classList.add('hidden');
    renderRapidStats();
    renderRapidDrill();
    await rapidNext();
  }

  function renderRapidMistakes() {
    const list = el('rapidMistakeList');
    list.innerHTML = '';
    if (!rapid.mistakes.length) {
      show('rapidMistakeEmpty');
      return;
    }
    hide('rapidMistakeEmpty');
    [...rapid.mistakes].reverse().forEach((m) => {
      const item = document.createElement('div');
      item.className = 'rapid-mistake' + (m.resolved ? ' resolved' : '');

      const head = document.createElement('div');
      head.className = 'rm-head';
      head.innerHTML = `
        <span class="tier-chip ${m.tier.key}">${m.tier.mark} ${m.tier.label}</span>
        <span class="rm-mode">${m.mode === 'locked' ? 'Locked NLH' : 'Arrange'}</span>
        <span class="rm-loss">−${m.loss.toFixed(2)} pts/hand</span>
        ${m.resolved ? '<span class="rm-fixed">✓ fixed on retry</span>' : m.attempts ? `<span class="rm-tries">${m.attempts} attempt${m.attempts === 1 ? '' : 's'}</span>` : ''}`;
      item.appendChild(head);

      const handWrap = document.createElement('div');
      handWrap.className = 'rm-hand';
      const hl = document.createElement('span');
      hl.className = 'hc-label';
      hl.textContent = 'Hand:';
      handWrap.appendChild(hl);
      handWrap.appendChild(cardRow(sortCards(m.hand, cardSortMode), { size: 'small' }));
      item.appendChild(handWrap);

      const cmp = document.createElement('div');
      cmp.className = 'rm-compare';
      [['You played', m.userAssignment, m.userEv, 'bad'], ['Best was', m.bestAssignment, m.bestEv, 'good']].forEach(([label, assignment, ev, cls]) => {
        const line = document.createElement('div');
        line.className = 'rm-line ' + cls;
        const lab = document.createElement('span');
        lab.className = 'hc-label';
        lab.textContent = label + ':';
        line.appendChild(lab);
        line.appendChild(splitGroupsNode(assignment));
        const evs = document.createElement('span');
        evs.className = 'rapid-opt-ev';
        evs.textContent = `${fmtEv(ev)} EV`;
        line.appendChild(evs);
        cmp.appendChild(line);
      });
      item.appendChild(cmp);

      const actions = document.createElement('div');
      actions.className = 'rm-actions';
      const retryBtn = document.createElement('button');
      retryBtn.className = 'secondary';
      retryBtn.textContent = m.resolved ? 'Retry again' : 'Retry this hand';
      retryBtn.addEventListener('click', () => startRapidRetry(m.id));
      actions.appendChild(retryBtn);
      const dropBtn = document.createElement('button');
      dropBtn.className = 'secondary';
      dropBtn.textContent = 'Remove';
      dropBtn.addEventListener('click', () => {
        rapid.mistakes = rapid.mistakes.filter((x) => x.id !== m.id);
        renderRapidStats();
        renderRapidMistakes();
      });
      actions.appendChild(dropBtn);
      item.appendChild(actions);

      list.appendChild(item);
    });
  }

  // Re-drill a stored mistake on the exact same hand and boards, graded against the same
  // precomputed solve — so a retry is a real second attempt at the same problem, with the
  // arrangement cleared so you have to rebuild it rather than recognize a position.
  function startRapidRetry(mistakeId) {
    const m = rapid.mistakes.find((x) => x.id === mistakeId);
    if (!m) return;
    const base = { hand: m.hand, trials: m.trials, solved: m.solved, solvePromise: Promise.resolve(m.solved),
      answered: false, assisted: false };
    const quiz = m.mode === 'locked'
      ? Object.assign({ mode: 'locked', lockedTwo: m.lockedTwo, rest: m.rest, parts: m.parts, chosenCard: null }, base)
      : Object.assign({ mode: 'arrange' }, base, emptyArrangeFields());
    rapid.retry = { mistake: m, quiz };
    el('rapidFeedback').classList.add('hidden');
    setPracticeMode(m.mode === 'locked' ? 'locked' : 'arrange');
  }

  // The drills and free play are one screen now, so "view" just records which of the two
  // drill panes is showing; which top-level mode is active lives in practiceMode.
  function setRapidView(view) {
    if (!rapid) return;
    rapid.view = view;
    if (view === 'drill') renderRapidDrill(); else renderRapidMistakes();
  }

  function ensureRapidState() {
    if (!rapid) {
      rapid = rapidNewState();
      renderRapidStats();
      renderRapidMistakes();
    }
    return rapid;
  }

  el('btnRapidNext').addEventListener('click', () => rapidNext());
  el('btnRapidSubmit').addEventListener('click', () => rapidSubmitArrange());
  el('btnRapidEstSubmit').addEventListener('click', () => rapidSubmitEstimate());
  el('btnRapidClear').addEventListener('click', () => {
    const quiz = rapidActiveQuiz();
    if (!quiz || quiz.answered || !rapidUsesArranger(quiz)) return;
    Object.assign(quiz, emptyArrangeFields());
    renderRapidDrill();
  });

  el('rapidAssist').addEventListener('change', () => {
    if (!rapid) return;
    rapid.assist = el('rapidAssist').checked;
    // Turning the assist on mid-hand marks that hand assisted (you're about to see the
    // answer); turning it off can't un-see it, so the hand stays marked for the rest of it.
    const quiz = rapidActiveQuiz();
    if (quiz && rapid.assist) quiz.assisted = true;
    renderRapidDrill();
  });
  RAPID_CATS.forEach((cat) => {
    el('rapidEst' + capitalize(cat)).addEventListener('input', renderRapidEstTotal);
  });

  wireSortControl('rapidSortControl', () => { if (rapid && rapid.view === 'drill') renderRapidDrill(); });

  document.addEventListener('keydown', (ev) => {
    if (!rapid || el('screen-practice').classList.contains('hidden')) return;
    if (practiceMode !== 'arrange' && practiceMode !== 'estimate' && practiceMode !== 'locked') return;
    const quiz = rapidActiveQuiz();
    // Only text entry should swallow the number keys — a focused checkbox (the assist
    // toggle) must not stop 1-7 from placing cards.
    const t = ev.target;
    const typing = !!t && (/^(TEXTAREA|SELECT)$/.test(t.tagName)
      || (t.tagName === 'INPUT' && t.type !== 'checkbox'));

    if (ev.key === 'Enter') {
      ev.preventDefault();
      if (!quiz) return;
      if (quiz.answered) rapidNext(); else rapidSubmit();
      return;
    }
    if (typing || !quiz || quiz.answered) return;

    if (/^[1-9]$/.test(ev.key)) {
      const i = Number(ev.key) - 1;
      if (rapidUsesArranger(quiz)) {
        const tray = rapidTrayCards(quiz);
        if (i < tray.length) {
          ev.preventDefault();
          rapidPlaceFirstOpen(quiz, tray[i]);
          quiz.selected = null;
          renderRapidDrill();
          // Once the split is complete in estimate mode, jump straight to pricing it.
          if (quiz.mode === 'estimate' && rapidArrangeComplete(quiz)) el('rapidEstOne').focus();
        }
      } else if (quiz.mode === 'locked') {
        const choices = sortCards(quiz.rest, cardSortMode);
        if (i < choices.length) { ev.preventDefault(); rapidAnswerLocked(choices[i]); }
      }
      return;
    }
    if (ev.key === 'Backspace' && rapidUsesArranger(quiz) && quiz.placeOrder.length) {
      ev.preventDefault();
      rapidUnplace(quiz, quiz.placeOrder[quiz.placeOrder.length - 1].card);
      renderRapidDrill();
    }
  });

  // ---------- boot / rejoin ----------
  const params = new URLSearchParams(location.search);
  const joinParam = params.get('join');
  if (joinParam) el('joinCode').value = joinParam.toUpperCase();
  if (joinParam) document.querySelector('.tab-btn[data-tab="join"]').click();

  const saved = loadSession();
  if (saved && saved.code && saved.playerId && saved.token) {
    state.code = saved.code; state.playerId = saved.playerId; state.token = saved.token; state.name = saved.name;
    let succeeded = false;
    const stream = connectStream();
    stream.addEventListener('room_state', () => { succeeded = true; }, { once: true });
    stream.onerror = () => {
      if (!succeeded) { clearSession(); state.code = null; state.playerId = null; state.token = null; stream.close(); }
    };
  }
})();
